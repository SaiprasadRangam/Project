import React, { useState, useEffect } from 'react';
import { BarChart3, Download, Filter, TrendingUp, TrendingDown, Package, Truck, MapPin, Wrench } from 'lucide-react';
import Sidebar from './Sidebar';
import './Reports.css';

const Reports = () => {
  const [reports, setReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    // Mock data - in real app, this would be an API call
    setReports([
      {
        id: 1,
        reportType: 'inventory',
        title: 'Inventory Turnover Report',
        description: 'Monthly inventory turnover analysis and stock levels',
        generatedOn: '2024-01-15',
        status: 'completed',
        details: {
          totalItems: 1247,
          turnoverRate: 85,
          lowStockItems: 12,
          overstockItems: 5,
          totalValue: 125000
        }
      },
      {
        id: 2,
        reportType: 'shipment',
        title: 'Shipment Performance Report',
        description: 'Delivery times and shipment efficiency metrics',
        generatedOn: '2024-01-14',
        status: 'completed',
        details: {
          totalShipments: 156,
          onTimeDeliveries: 142,
          delayedShipments: 14,
          averageDeliveryTime: '2.3 days',
          customerSatisfaction: 91
        }
      },
      {
        id: 3,
        reportType: 'space',
        title: 'Space Utilization Report',
        description: 'Warehouse space usage and optimization opportunities',
        generatedOn: '2024-01-13',
        status: 'completed',
        details: {
          totalCapacity: 4100,
          usedSpace: 3075,
          utilizationRate: 75,
          availableSpace: 1025,
          optimizationPotential: 15
        }
      },
      {
        id: 4,
        reportType: 'maintenance',
        title: 'Equipment Maintenance Report',
        description: 'Equipment health and maintenance schedule compliance',
        generatedOn: '2024-01-12',
        status: 'completed',
        details: {
          totalEquipment: 25,
          scheduledMaintenance: 8,
          completedTasks: 15,
          overdueTasks: 2,
          equipmentUptime: 96
        }
      },
      {
        id: 5,
        reportType: 'financial',
        title: 'Financial Performance Report',
        description: 'Revenue, costs, and profitability analysis',
        generatedOn: '2024-01-11',
        status: 'completed',
        details: {
          totalRevenue: 450000,
          totalCosts: 320000,
          profitMargin: 29,
          operationalCosts: 85000,
          efficiencyRating: 88
        }
      }
    ]);
  }, []);

  const handleDownloadReport = (report) => {
    // Mock download functionality
    alert(`Downloading ${report.title}...`);
  };

  const handleViewReport = (report) => {
    setSelectedReport(report);
  };

  const filteredReports = filterType === 'all' 
    ? reports 
    : reports.filter(report => report.reportType === filterType);

  const getReportIcon = (type) => {
    switch (type) {
      case 'inventory':
        return <Package size={20} />;
      case 'shipment':
        return <Truck size={20} />;
      case 'space':
        return <MapPin size={20} />;
      case 'maintenance':
        return <Wrench size={20} />;
      default:
        return <BarChart3 size={20} />;
    }
  };

  const getReportTypeLabel = (type) => {
    const labels = {
      'inventory': 'Inventory',
      'shipment': 'Shipment',
      'space': 'Space',
      'maintenance': 'Maintenance',
      'financial': 'Financial'
    };
    return labels[type] || 'Other';
  };

  const getMetricTrend = (value, threshold = 50) => {
    return value >= threshold ? 'positive' : 'negative';
  };

  return (
    <div className="reports">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Reports & Analytics</h1>
          <p className="page-subtitle">Generate and view warehouse performance reports</p>
        </div>

        <div className="reports-controls">
          <div className="filter-controls">
            <Filter size={20} />
            <select 
              value={filterType} 
              onChange={(e) => setFilterType(e.target.value)}
              className="filter-select"
            >
              <option value="all">All Reports</option>
              <option value="inventory">Inventory</option>
              <option value="shipment">Shipment</option>
              <option value="space">Space</option>
              <option value="maintenance">Maintenance</option>
              <option value="financial">Financial</option>
            </select>
          </div>
          <button className="btn btn-primary">
            <BarChart3 size={20} />
            Generate New Report
          </button>
        </div>

        <div className="reports-grid">
          {filteredReports.map((report) => (
            <div key={report.id} className="report-card">
              <div className="report-header">
                <div className="report-icon">
                  {getReportIcon(report.reportType)}
                </div>
                <div className="report-meta">
                  <h3>{report.title}</h3>
                  <span className="report-type">{getReportTypeLabel(report.reportType)}</span>
                </div>
                <div className="report-actions">
                  <button
                    className="btn-icon"
                    onClick={() => handleViewReport(report)}
                    title="View Details"
                  >
                    <BarChart3 size={16} />
                  </button>
                  <button
                    className="btn-icon"
                    onClick={() => handleDownloadReport(report)}
                    title="Download"
                  >
                    <Download size={16} />
                  </button>
                </div>
              </div>
              
              <p className="report-description">{report.description}</p>
              
              <div className="report-metrics">
                {Object.entries(report.details).slice(0, 3).map(([key, value]) => (
                  <div key={key} className="metric-item">
                    <span className="metric-label">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</span>
                    <span className="metric-value">{typeof value === 'number' ? value.toLocaleString() : value}</span>
                  </div>
                ))}
              </div>
              
              <div className="report-footer">
                <span className="report-date">Generated: {report.generatedOn}</span>
                <span className={`report-status ${report.status}`}>{report.status}</span>
              </div>
            </div>
          ))}
        </div>

        {selectedReport && (
          <div className="report-details-modal">
            <div className="modal-overlay" onClick={() => setSelectedReport(null)}></div>
            <div className="modal-content">
              <div className="modal-header">
                <h2>{selectedReport.title}</h2>
                <button 
                  className="close-btn"
                  onClick={() => setSelectedReport(null)}
                >
                  ×
                </button>
              </div>
              
              <div className="modal-body">
                <div className="report-summary">
                  <p>{selectedReport.description}</p>
                  <div className="summary-stats">
                    <div className="summary-item">
                      <span className="label">Report Type:</span>
                      <span className="value">{getReportTypeLabel(selectedReport.reportType)}</span>
                    </div>
                    <div className="summary-item">
                      <span className="label">Generated On:</span>
                      <span className="value">{selectedReport.generatedOn}</span>
                    </div>
                    <div className="summary-item">
                      <span className="label">Status:</span>
                      <span className={`value status-${selectedReport.status}`}>{selectedReport.status}</span>
                    </div>
                  </div>
                </div>
                
                <div className="detailed-metrics">
                  <h3>Detailed Metrics</h3>
                  <div className="metrics-grid">
                    {Object.entries(selectedReport.details).map(([key, value]) => (
                      <div key={key} className="metric-card">
                        <div className="metric-header">
                          <span className="metric-name">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</span>
                          {typeof value === 'number' && (
                            <div className={`trend-indicator ${getMetricTrend(value)}`}>
                              {getMetricTrend(value) === 'positive' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                            </div>
                          )}
                        </div>
                        <div className="metric-value-large">
                          {typeof value === 'number' ? value.toLocaleString() : value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="modal-footer">
                <button 
                  className="btn btn-primary"
                  onClick={() => handleDownloadReport(selectedReport)}
                >
                  <Download size={16} />
                  Download Report
                </button>
                <button 
                  className="btn btn-secondary"
                  onClick={() => setSelectedReport(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reports;
