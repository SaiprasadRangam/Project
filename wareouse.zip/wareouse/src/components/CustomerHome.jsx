import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, Truck, MapPin, Clock, Phone, Mail, ArrowRight } from 'lucide-react';
import './CustomerHome.css';

const CustomerHome = () => {
  const [trackingNumber, setTrackingNumber] = useState('');

  const handleTrackShipment = (e) => {
    e.preventDefault();
    if (trackingNumber.trim()) {
      alert(`Tracking shipment: ${trackingNumber}`);
    } else {
      alert('Please enter a tracking number');
    }
  };

  const services = [
    {
      icon: <Package size={24} />,
      title: 'Inventory Tracking',
      description: 'Track your inventory levels and stock movements in real-time',
      link: '/login'
    },
    {
      icon: <Truck size={24} />,
      title: 'Shipment Tracking',
      description: 'Monitor your shipments from pickup to delivery',
      link: '/login'
    },
    {
      icon: <MapPin size={24} />,
      title: 'Space Management',
      description: 'Optimize warehouse space allocation for your goods',
      link: '/login'
    },
    {
      icon: <Clock size={24} />,
      title: 'Performance Reports',
      description: 'Access detailed reports on warehouse operations',
      link: '/login'
    }
  ];

  const stats = [
    { label: 'Active Shipments', value: '156' },
    { label: 'Total Items Stored', value: '1,247' },
    { label: 'Space Utilization', value: '75%' },
    { label: 'Customer Satisfaction', value: '98%' }
  ];

  return (
    <div className="customer-home">
      <header className="customer-header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <h1>LWMS</h1>
              <p>Logistics Warehouse Management System</p>
            </div>
            <nav className="nav-links">
              <Link to="/login" className="nav-link">Admin Login</Link>
              <Link to="/register" className="nav-link">Register</Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="customer-main">
        <section className="hero-section">
          <div className="container">
            <div className="hero-content">
              <h1>Welcome to Our Warehouse Management System</h1>
              <p>Efficient, reliable, and secure logistics solutions for your business needs</p>
              
              <div className="tracking-section">
                <h3>Track Your Shipment</h3>
                <form onSubmit={handleTrackShipment} className="tracking-form">
                  <input
                    type="text"
                    placeholder="Enter tracking number..."
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    className="tracking-input"
                  />
                  <button type="submit" className="tracking-btn">
                    Track
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        <section className="stats-section">
          <div className="container">
            <div className="stats-grid">
              {stats.map((stat, index) => (
                <div key={index} className="stat-card">
                  <div className="stat-number">{stat.value}</div>
                  <div className="stat-label">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="services-section">
          <div className="container">
            <h2>Our Services</h2>
            <div className="services-grid">
              {services.map((service, index) => (
                <div key={index} className="service-card">
                  <div className="service-icon">
                    {service.icon}
                  </div>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to={service.link} className="service-link">
                    Learn More <ArrowRight size={16} />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="features-section">
          <div className="container">
            <h2>Why Choose Our Warehouse Management System?</h2>
            <div className="features-grid">
              <div className="feature-item">
                <h3>Real-time Tracking</h3>
                <p>Monitor your inventory and shipments in real-time with our advanced tracking system.</p>
              </div>
              <div className="feature-item">
                <h3>Space Optimization</h3>
                <p>Maximize warehouse efficiency with intelligent space allocation and management.</p>
              </div>
              <div className="feature-item">
                <h3>Automated Processes</h3>
                <p>Reduce manual errors and increase productivity with automated warehouse operations.</p>
              </div>
              <div className="feature-item">
                <h3>Comprehensive Reporting</h3>
                <p>Get detailed insights into your warehouse performance with comprehensive analytics.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="cta-section">
          <div className="container">
            <div className="cta-content">
              <h2>Ready to Get Started?</h2>
              <p>Join thousands of businesses that trust our warehouse management system</p>
              <div className="cta-buttons">
                <Link to="/register" className="btn btn-primary">
                  Get Started
                </Link>
                <Link to="/login" className="btn btn-secondary">
                  Admin Login
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="customer-footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-section">
              <h3>LWMS</h3>
              <p>Logistics Warehouse Management System</p>
              <p>Efficient warehouse management solutions for modern businesses.</p>
            </div>
            <div className="footer-section">
              <h4>Contact Us</h4>
              <div className="contact-info">
                <div className="contact-item">
                  <Phone size={16} />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="contact-item">
                  <Mail size={16} />
                  <span>info@lwms.com</span>
                </div>
              </div>
            </div>
            <div className="footer-section">
              <h4>Quick Links</h4>
              <ul className="footer-links">
                <li><Link to="/login">Admin Login</Link></li>
                <li><Link to="/register">Register</Link></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2024 LWMS. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CustomerHome;
