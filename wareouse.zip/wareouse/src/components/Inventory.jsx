import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2, Package } from 'lucide-react';
import Sidebar from './Sidebar';
import './Inventory.css';

const Inventory = () => {
  const [inventory, setInventory] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({
    itemName: '',
    category: '',
    quantity: '',
    location: ''
  });

  useEffect(() => {
    // Mock data - in real app, this would be an API call
    setInventory([
      {
        id: 1,
        itemName: 'Laptop Dell XPS 13',
        category: 'Electronics',
        quantity: 25,
        location: 'Zone A - Shelf 1',
        lastUpdated: '2024-01-15'
      },
      {
        id: 2,
        itemName: 'Office Chair Ergonomic',
        category: 'Furniture',
        quantity: 15,
        location: 'Zone B - Shelf 3',
        lastUpdated: '2024-01-14'
      },
      {
        id: 3,
        itemName: 'Wireless Mouse Logitech',
        category: 'Electronics',
        quantity: 50,
        location: 'Zone A - Shelf 2',
        lastUpdated: '2024-01-13'
      },
      {
        id: 4,
        itemName: 'Desk Lamp LED',
        category: 'Furniture',
        quantity: 30,
        location: 'Zone C - Shelf 1',
        lastUpdated: '2024-01-12'
      },
      {
        id: 5,
        itemName: 'USB Cable Type-C',
        category: 'Electronics',
        quantity: 100,
        location: 'Zone A - Shelf 3',
        lastUpdated: '2024-01-11'
      }
    ]);
  }, []);

  const handleAddItem = (e) => {
    e.preventDefault();
    const newItem = {
      id: inventory.length + 1,
      ...formData,
      quantity: parseInt(formData.quantity),
      lastUpdated: new Date().toISOString().split('T')[0]
    };
    setInventory([...inventory, newItem]);
    setFormData({ itemName: '', category: '', quantity: '', location: '' });
    setShowAddForm(false);
  };

  const handleEditItem = (item) => {
    setEditingItem(item);
    setFormData({
      itemName: item.itemName,
      category: item.category,
      quantity: item.quantity.toString(),
      location: item.location
    });
    setShowAddForm(true);
  };

  const handleUpdateItem = (e) => {
    e.preventDefault();
    const updatedInventory = inventory.map(item =>
      item.id === editingItem.id
        ? { ...item, ...formData, quantity: parseInt(formData.quantity), lastUpdated: new Date().toISOString().split('T')[0] }
        : item
    );
    setInventory(updatedInventory);
    setFormData({ itemName: '', category: '', quantity: '', location: '' });
    setEditingItem(null);
    setShowAddForm(false);
  };

  const handleDeleteItem = (id) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      setInventory(inventory.filter(item => item.id !== id));
    }
  };

  const filteredInventory = inventory.filter(item =>
    item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getQuantityStatus = (quantity) => {
    if (quantity <= 10) return 'low';
    if (quantity <= 30) return 'medium';
    return 'high';
  };

  return (
    <div className="inventory">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Inventory Management</h1>
          <p className="page-subtitle">Manage warehouse inventory items</p>
        </div>

        <div className="inventory-controls">
          <div className="search-bar">
            <Search size={20} />
            <input
              type="text"
              placeholder="Search items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button
            className="btn btn-primary"
            onClick={() => {
              setShowAddForm(true);
              setEditingItem(null);
              setFormData({ itemName: '', category: '', quantity: '', location: '' });
            }}
          >
            <Plus size={20} />
            Add Item
          </button>
        </div>

        {showAddForm && (
          <div className="form-container">
            <div className="card">
              <h3>{editingItem ? 'Edit Item' : 'Add New Item'}</h3>
              <form onSubmit={editingItem ? handleUpdateItem : handleAddItem}>
                <div className="form-group">
                  <label>Item Name</label>
                  <input
                    type="text"
                    value={formData.itemName}
                    onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                  >
                    <option value="">Select Category</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Furniture">Furniture</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Books">Books</option>
                    <option value="Tools">Tools</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Quantity</label>
                  <input
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    min="0"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    required
                  />
                </div>
                <div className="action-buttons">
                  <button type="submit" className="btn btn-success">
                    {editingItem ? 'Update Item' : 'Add Item'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingItem(null);
                      setFormData({ itemName: '', category: '', quantity: '', location: '' });
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="inventory-table">
          <div className="card">
            <table className="table">
              <thead>
                <tr>
                  <th>Item Name</th>
                  <th>Category</th>
                  <th>Quantity</th>
                  <th>Location</th>
                  <th>Last Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredInventory.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <div className="item-info">
                        <Package size={16} />
                        <span>{item.itemName}</span>
                      </div>
                    </td>
                    <td>
                      <span className="category-badge">{item.category}</span>
                    </td>
                    <td>
                      <span className={`quantity-badge ${getQuantityStatus(item.quantity)}`}>
                        {item.quantity}
                      </span>
                    </td>
                    <td>{item.location}</td>
                    <td>{item.lastUpdated}</td>
                    <td>
                      <div className="action-buttons">
                        <button
                          className="btn-icon"
                          onClick={() => handleEditItem(item)}
                          title="Edit"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          className="btn-icon danger"
                          onClick={() => handleDeleteItem(item.id)}
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
