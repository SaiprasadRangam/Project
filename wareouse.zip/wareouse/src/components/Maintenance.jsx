import React, { useState, useEffect } from 'react';
import { Wrench, Plus, Edit, Trash2, Calendar, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import Sidebar from './Sidebar';
import './Maintenance.css';

const Maintenance = () => {
  const [maintenanceTasks, setMaintenanceTasks] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [formData, setFormData] = useState({
    equipmentId: '',
    equipmentName: '',
    taskDescription: '',
    scheduledDate: '',
    priority: 'medium',
    assignedTo: '',
    status: 'scheduled'
  });

  useEffect(() => {
    // Mock data - in real app, this would be an API call
    setMaintenanceTasks([
      {
        id: 1,
        equipmentId: 'FL-001',
        equipmentName: 'Forklift Toyota',
        taskDescription: 'Regular maintenance and oil change',
        scheduledDate: '2024-01-20',
        priority: 'high',
        assignedTo: 'John Smith',
        status: 'scheduled',
        createdAt: '2024-01-15'
      },
      {
        id: 2,
        equipmentId: 'CR-002',
        equipmentName: 'Crane System',
        taskDescription: 'Safety inspection and cable replacement',
        scheduledDate: '2024-01-25',
        priority: 'high',
        assignedTo: 'Mike Johnson',
        status: 'in-progress',
        createdAt: '2024-01-12'
      },
      {
        id: 3,
        equipmentId: 'HV-003',
        equipmentName: 'HVAC System',
        taskDescription: 'Filter replacement and system check',
        scheduledDate: '2024-01-18',
        priority: 'medium',
        assignedTo: 'Sarah Wilson',
        status: 'completed',
        createdAt: '2024-01-10'
      },
      {
        id: 4,
        equipmentId: 'SC-004',
        equipmentName: 'Security System',
        taskDescription: 'Camera maintenance and software update',
        scheduledDate: '2024-01-30',
        priority: 'low',
        assignedTo: 'David Brown',
        status: 'scheduled',
        createdAt: '2024-01-14'
      },
      {
        id: 5,
        equipmentId: 'LG-005',
        equipmentName: 'Loading Dock',
        taskDescription: 'Hydraulic system inspection',
        scheduledDate: '2024-01-22',
        priority: 'medium',
        assignedTo: 'Lisa Davis',
        status: 'overdue',
        createdAt: '2024-01-08'
      }
    ]);
  }, []);

  const handleAddTask = (e) => {
    e.preventDefault();
    const newTask = {
      id: maintenanceTasks.length + 1,
      ...formData,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setMaintenanceTasks([...maintenanceTasks, newTask]);
    setFormData({
      equipmentId: '',
      equipmentName: '',
      taskDescription: '',
      scheduledDate: '',
      priority: 'medium',
      assignedTo: '',
      status: 'scheduled'
    });
    setShowAddForm(false);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setFormData({
      equipmentId: task.equipmentId,
      equipmentName: task.equipmentName,
      taskDescription: task.taskDescription,
      scheduledDate: task.scheduledDate,
      priority: task.priority,
      assignedTo: task.assignedTo,
      status: task.status
    });
    setShowAddForm(true);
  };

  const handleUpdateTask = (e) => {
    e.preventDefault();
    const updatedTasks = maintenanceTasks.map(task =>
      task.id === editingTask.id
        ? { ...task, ...formData }
        : task
    );
    setMaintenanceTasks(updatedTasks);
    setFormData({
      equipmentId: '',
      equipmentName: '',
      taskDescription: '',
      scheduledDate: '',
      priority: 'medium',
      assignedTo: '',
      status: 'scheduled'
    });
    setEditingTask(null);
    setShowAddForm(false);
  };

  const handleDeleteTask = (id) => {
    if (window.confirm('Are you sure you want to delete this maintenance task?')) {
      setMaintenanceTasks(maintenanceTasks.filter(task => task.id !== id));
    }
  };

  const getPriorityBadge = (priority) => {
    const priorityConfig = {
      'low': { class: 'low', label: 'Low' },
      'medium': { class: 'medium', label: 'Medium' },
      'high': { class: 'high', label: 'High' }
    };
    
    const config = priorityConfig[priority] || priorityConfig['medium'];
    return <span className={`priority-badge ${config.class}`}>{config.label}</span>;
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'scheduled': { class: 'scheduled', label: 'Scheduled', icon: <Clock size={14} /> },
      'in-progress': { class: 'in-progress', label: 'In Progress', icon: <Wrench size={14} /> },
      'completed': { class: 'completed', label: 'Completed', icon: <CheckCircle size={14} /> },
      'overdue': { class: 'overdue', label: 'Overdue', icon: <AlertCircle size={14} /> }
    };
    
    const config = statusConfig[status] || statusConfig['scheduled'];
    return (
      <span className={`status-badge ${config.class}`}>
        {config.icon}
        <span>{config.label}</span>
      </span>
    );
  };

  const scheduledTasks = maintenanceTasks.filter(t => t.status === 'scheduled').length;
  const inProgressTasks = maintenanceTasks.filter(t => t.status === 'in-progress').length;
  const completedTasks = maintenanceTasks.filter(t => t.status === 'completed').length;
  const overdueTasks = maintenanceTasks.filter(t => t.status === 'overdue').length;

  return (
    <div className="maintenance">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Maintenance Management</h1>
          <p className="page-subtitle">Schedule and track equipment maintenance</p>
        </div>

        <div className="maintenance-stats">
          <div className="stat-card">
            <div className="stat-icon scheduled">
              <Clock size={24} />
            </div>
            <div className="stat-number">{scheduledTasks}</div>
            <div className="stat-label">Scheduled</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon in-progress">
              <Wrench size={24} />
            </div>
            <div className="stat-number">{inProgressTasks}</div>
            <div className="stat-label">In Progress</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon completed">
              <CheckCircle size={24} />
            </div>
            <div className="stat-number">{completedTasks}</div>
            <div className="stat-label">Completed</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon overdue">
              <AlertCircle size={24} />
            </div>
            <div className="stat-number">{overdueTasks}</div>
            <div className="stat-label">Overdue</div>
          </div>
        </div>

        <div className="maintenance-controls">
          <button
            className="btn btn-primary"
            onClick={() => {
              setShowAddForm(true);
              setEditingTask(null);
              setFormData({
                equipmentId: '',
                equipmentName: '',
                taskDescription: '',
                scheduledDate: '',
                priority: 'medium',
                assignedTo: '',
                status: 'scheduled'
              });
            }}
          >
            <Plus size={20} />
            Schedule Maintenance
          </button>
        </div>

        {showAddForm && (
          <div className="form-container">
            <div className="card">
              <h3>{editingTask ? 'Edit Maintenance Task' : 'Schedule New Maintenance'}</h3>
              <form onSubmit={editingTask ? handleUpdateTask : handleAddTask}>
                <div className="form-row">
                  <div className="form-group">
                    <label>Equipment ID</label>
                    <input
                      type="text"
                      value={formData.equipmentId}
                      onChange={(e) => setFormData({ ...formData, equipmentId: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Equipment Name</label>
                    <input
                      type="text"
                      value={formData.equipmentName}
                      onChange={(e) => setFormData({ ...formData, equipmentName: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>Task Description</label>
                  <textarea
                    value={formData.taskDescription}
                    onChange={(e) => setFormData({ ...formData, taskDescription: e.target.value })}
                    rows="3"
                    required
                  />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Scheduled Date</label>
                    <input
                      type="date"
                      value={formData.scheduledDate}
                      onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Priority</label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                      required
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Assigned To</label>
                    <input
                      type="text"
                      value={formData.assignedTo}
                      onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Status</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                      required
                    >
                      <option value="scheduled">Scheduled</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="overdue">Overdue</option>
                    </select>
                  </div>
                </div>
                <div className="action-buttons">
                  <button type="submit" className="btn btn-success">
                    {editingTask ? 'Update Task' : 'Schedule Task'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingTask(null);
                      setFormData({
                        equipmentId: '',
                        equipmentName: '',
                        taskDescription: '',
                        scheduledDate: '',
                        priority: 'medium',
                        assignedTo: '',
                        status: 'scheduled'
                      });
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="maintenance-table">
          <div className="card">
            <table className="table">
              <thead>
                <tr>
                  <th>Equipment</th>
                  <th>Task Description</th>
                  <th>Scheduled Date</th>
                  <th>Priority</th>
                  <th>Assigned To</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {maintenanceTasks.map((task) => (
                  <tr key={task.id}>
                    <td>
                      <div className="equipment-info">
                        <Wrench size={16} />
                        <div>
                          <div className="equipment-id">{task.equipmentId}</div>
                          <div className="equipment-name">{task.equipmentName}</div>
                        </div>
                      </div>
                    </td>
                    <td>{task.taskDescription}</td>
                    <td>
                      <div className="date-info">
                        <Calendar size={14} />
                        <span>{task.scheduledDate}</span>
                      </div>
                    </td>
                    <td>{getPriorityBadge(task.priority)}</td>
                    <td>{task.assignedTo}</td>
                    <td>{getStatusBadge(task.status)}</td>
                    <td>
                      <div className="action-buttons">
                        <button
                          className="btn-icon"
                          onClick={() => handleEditTask(task)}
                          title="Edit"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          className="btn-icon danger"
                          onClick={() => handleDeleteTask(task.id)}
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Maintenance;
