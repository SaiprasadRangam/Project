import React, { useState, useEffect } from 'react';
import { MapPin, Plus, Edit, Trash2, TrendingUp } from 'lucide-react';
import Sidebar from './Sidebar';
import './Space.css';

const Space = () => {
  const [spaces, setSpaces] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingSpace, setEditingSpace] = useState(null);
  const [formData, setFormData] = useState({
    zone: '',
    totalCapacity: '',
    usedCapacity: '',
    description: ''
  });

  useEffect(() => {
    // Mock data - in real app, this would be an API call
    setSpaces([
      {
        id: 1,
        zone: 'Zone A',
        totalCapacity: 1000,
        usedCapacity: 750,
        availableCapacity: 250,
        description: 'Electronics and Gadgets Storage',
        utilizationRate: 75
      },
      {
        id: 2,
        zone: 'Zone B',
        totalCapacity: 800,
        usedCapacity: 600,
        availableCapacity: 200,
        description: 'Furniture and Home Goods',
        utilizationRate: 75
      },
      {
        id: 3,
        zone: 'Zone C',
        totalCapacity: 1200,
        usedCapacity: 900,
        availableCapacity: 300,
        description: 'Clothing and Textiles',
        utilizationRate: 75
      },
      {
        id: 4,
        zone: 'Zone D',
        totalCapacity: 600,
        usedCapacity: 450,
        availableCapacity: 150,
        description: 'Tools and Equipment',
        utilizationRate: 75
      },
      {
        id: 5,
        zone: 'Zone E',
        totalCapacity: 500,
        usedCapacity: 200,
        availableCapacity: 300,
        description: 'Books and Stationery',
        utilizationRate: 40
      }
    ]);
  }, []);

  const handleAddSpace = (e) => {
    e.preventDefault();
    const usedCapacity = parseInt(formData.usedCapacity);
    const totalCapacity = parseInt(formData.totalCapacity);
    const availableCapacity = totalCapacity - usedCapacity;
    const utilizationRate = Math.round((usedCapacity / totalCapacity) * 100);

    const newSpace = {
      id: spaces.length + 1,
      ...formData,
      totalCapacity,
      usedCapacity,
      availableCapacity,
      utilizationRate
    };
    setSpaces([...spaces, newSpace]);
    setFormData({ zone: '', totalCapacity: '', usedCapacity: '', description: '' });
    setShowAddForm(false);
  };

  const handleEditSpace = (space) => {
    setEditingSpace(space);
    setFormData({
      zone: space.zone,
      totalCapacity: space.totalCapacity.toString(),
      usedCapacity: space.usedCapacity.toString(),
      description: space.description
    });
    setShowAddForm(true);
  };

  const handleUpdateSpace = (e) => {
    e.preventDefault();
    const usedCapacity = parseInt(formData.usedCapacity);
    const totalCapacity = parseInt(formData.totalCapacity);
    const availableCapacity = totalCapacity - usedCapacity;
    const utilizationRate = Math.round((usedCapacity / totalCapacity) * 100);

    const updatedSpaces = spaces.map(space =>
      space.id === editingSpace.id
        ? { ...space, ...formData, totalCapacity, usedCapacity, availableCapacity, utilizationRate }
        : space
    );
    setSpaces(updatedSpaces);
    setFormData({ zone: '', totalCapacity: '', usedCapacity: '', description: '' });
    setEditingSpace(null);
    setShowAddForm(false);
  };

  const handleDeleteSpace = (id) => {
    if (window.confirm('Are you sure you want to delete this space zone?')) {
      setSpaces(spaces.filter(space => space.id !== id));
    }
  };

  const getUtilizationStatus = (rate) => {
    if (rate >= 90) return 'critical';
    if (rate >= 75) return 'high';
    if (rate >= 50) return 'medium';
    return 'low';
  };

  const totalCapacity = spaces.reduce((sum, space) => sum + space.totalCapacity, 0);
  const totalUsed = spaces.reduce((sum, space) => sum + space.usedCapacity, 0);
  const totalAvailable = totalCapacity - totalUsed;
  const overallUtilization = totalCapacity > 0 ? Math.round((totalUsed / totalCapacity) * 100) : 0;

  return (
    <div className="space">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Space Management</h1>
          <p className="page-subtitle">Optimize warehouse space allocation</p>
        </div>

        <div className="space-overview">
          <div className="overview-card">
            <div className="overview-icon">
              <MapPin size={24} />
            </div>
            <div className="overview-content">
              <h3>Total Capacity</h3>
              <p>{totalCapacity.toLocaleString()} sq ft</p>
            </div>
          </div>
          <div className="overview-card">
            <div className="overview-icon">
              <TrendingUp size={24} />
            </div>
            <div className="overview-content">
              <h3>Utilization Rate</h3>
              <p>{overallUtilization}%</p>
            </div>
          </div>
          <div className="overview-card">
            <div className="overview-icon">
              <MapPin size={24} />
            </div>
            <div className="overview-content">
              <h3>Available Space</h3>
              <p>{totalAvailable.toLocaleString()} sq ft</p>
            </div>
          </div>
        </div>

        <div className="space-controls">
          <button
            className="btn btn-primary"
            onClick={() => {
              setShowAddForm(true);
              setEditingSpace(null);
              setFormData({ zone: '', totalCapacity: '', usedCapacity: '', description: '' });
            }}
          >
            <Plus size={20} />
            Add Zone
          </button>
        </div>

        {showAddForm && (
          <div className="form-container">
            <div className="card">
              <h3>{editingSpace ? 'Edit Zone' : 'Add New Zone'}</h3>
              <form onSubmit={editingSpace ? handleUpdateSpace : handleAddSpace}>
                <div className="form-group">
                  <label>Zone Name</label>
                  <input
                    type="text"
                    value={formData.zone}
                    onChange={(e) => setFormData({ ...formData, zone: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Total Capacity (sq ft)</label>
                  <input
                    type="number"
                    value={formData.totalCapacity}
                    onChange={(e) => setFormData({ ...formData, totalCapacity: e.target.value })}
                    min="0"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Used Capacity (sq ft)</label>
                  <input
                    type="number"
                    value={formData.usedCapacity}
                    onChange={(e) => setFormData({ ...formData, usedCapacity: e.target.value })}
                    min="0"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows="3"
                    required
                  />
                </div>
                <div className="action-buttons">
                  <button type="submit" className="btn btn-success">
                    {editingSpace ? 'Update Zone' : 'Add Zone'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingSpace(null);
                      setFormData({ zone: '', totalCapacity: '', usedCapacity: '', description: '' });
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="space-grid">
          {spaces.map((space) => (
            <div key={space.id} className="space-card">
              <div className="space-header">
                <div className="space-title">
                  <MapPin size={20} />
                  <h3>{space.zone}</h3>
                </div>
                <div className="space-actions">
                  <button
                    className="btn-icon"
                    onClick={() => handleEditSpace(space)}
                    title="Edit"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    className="btn-icon danger"
                    onClick={() => handleDeleteSpace(space.id)}
                    title="Delete"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <p className="space-description">{space.description}</p>
              
              <div className="space-stats">
                <div className="stat-item">
                  <span className="stat-label">Total:</span>
                  <span className="stat-value">{space.totalCapacity.toLocaleString()} sq ft</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Used:</span>
                  <span className="stat-value">{space.usedCapacity.toLocaleString()} sq ft</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Available:</span>
                  <span className="stat-value">{space.availableCapacity.toLocaleString()} sq ft</span>
                </div>
              </div>
              
              <div className="utilization-bar">
                <div className="utilization-label">
                  <span>Utilization Rate</span>
                  <span className={`utilization-rate ${getUtilizationStatus(space.utilizationRate)}`}>
                    {space.utilizationRate}%
                  </span>
                </div>
                <div className="progress-bar">
                  <div 
                    className={`progress-fill ${getUtilizationStatus(space.utilizationRate)}`}
                    style={{ width: `${space.utilizationRate}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Space;
