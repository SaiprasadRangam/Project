import React, { useState, useEffect } from 'react';
import { 
  Package, 
  MapPin, 
  Truck, 
  Wrench, 
  TrendingUp, 
  AlertCircle,
  Clock,
  CheckCircle
} from 'lucide-react';
import Sidebar from './Sidebar';
import './Dashboard.css';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalItems: 0,
    availableSpace: 0,
    activeShipments: 0,
    pendingMaintenance: 0
  });

  const [recentActivities, setRecentActivities] = useState([]);

  useEffect(() => {
    // Mock data - in real app, this would be API calls
    setStats({
      totalItems: 1247,
      availableSpace: 75,
      activeShipments: 23,
      pendingMaintenance: 5
    });

    setRecentActivities([
      {
        id: 1,
        type: 'inventory',
        message: 'New shipment received - 50 units of Electronics',
        time: '2 hours ago',
        status: 'completed'
      },
      {
        id: 2,
        type: 'shipment',
        message: 'Shipment #SH-2024-001 dispatched to Customer A',
        time: '4 hours ago',
        status: 'completed'
      },
      {
        id: 3,
        type: 'maintenance',
        message: 'Scheduled maintenance for Forklift #FL-001',
        time: '6 hours ago',
        status: 'pending'
      },
      {
        id: 4,
        type: 'space',
        message: 'Space optimization completed - Zone A',
        time: '1 day ago',
        status: 'completed'
      },
      {
        id: 5,
        type: 'inventory',
        message: 'Low stock alert - Item #ITM-045',
        time: '1 day ago',
        status: 'alert'
      }
    ]);
  }, []);

  const getActivityIcon = (type) => {
    switch (type) {
      case 'inventory':
        return <Package size={16} />;
      case 'shipment':
        return <Truck size={16} />;
      case 'maintenance':
        return <Wrench size={16} />;
      case 'space':
        return <MapPin size={16} />;
      default:
        return <Clock size={16} />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={16} className="status-icon completed" />;
      case 'pending':
        return <Clock size={16} className="status-icon pending" />;
      case 'alert':
        return <AlertCircle size={16} className="status-icon alert" />;
      default:
        return <Clock size={16} className="status-icon pending" />;
    }
  };

  return (
    <div className="dashboard">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Welcome to the Warehouse Management System</p>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon inventory">
              <Package size={24} />
            </div>
            <div className="stat-number">{stats.totalItems.toLocaleString()}</div>
            <div className="stat-label">Total Items</div>
          </div>

          <div className="stat-card">
            <div className="stat-icon space">
              <MapPin size={24} />
            </div>
            <div className="stat-number">{stats.availableSpace}%</div>
            <div className="stat-label">Available Space</div>
          </div>

          <div className="stat-card">
            <div className="stat-icon shipment">
              <Truck size={24} />
            </div>
            <div className="stat-number">{stats.activeShipments}</div>
            <div className="stat-label">Active Shipments</div>
          </div>

          <div className="stat-card">
            <div className="stat-icon maintenance">
              <Wrench size={24} />
            </div>
            <div className="stat-number">{stats.pendingMaintenance}</div>
            <div className="stat-label">Pending Maintenance</div>
          </div>
        </div>

        <div className="dashboard-content">
          <div className="recent-activities">
            <div className="section-header">
              <h2>Recent Activities</h2>
              <TrendingUp size={20} />
            </div>
            
            <div className="activities-list">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="activity-item">
                  <div className="activity-icon">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="activity-content">
                    <p className="activity-message">{activity.message}</p>
                    <span className="activity-time">{activity.time}</span>
                  </div>
                  <div className="activity-status">
                    {getStatusIcon(activity.status)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="quick-actions">
            <div className="section-header">
              <h2>Quick Actions</h2>
            </div>
            
            <div className="actions-grid">
              <button className="action-btn">
                <Package size={20} />
                <span>Add Item</span>
              </button>
              <button className="action-btn">
                <Truck size={20} />
                <span>New Shipment</span>
              </button>
              <button className="action-btn">
                <Wrench size={20} />
                <span>Schedule Maintenance</span>
              </button>
              <button className="action-btn">
                <MapPin size={20} />
                <span>Space Report</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
