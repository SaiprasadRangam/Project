import React, { useState, useEffect } from 'react';
import { Truck, Plus, Edit, Trash2, Package, Calendar, MapPin } from 'lucide-react';
import Sidebar from './Sidebar';
import './Shipment.css';

const Shipment = () => {
  const [shipments, setShipments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingShipment, setEditingShipment] = useState(null);
  const [formData, setFormData] = useState({
    shipmentId: '',
    itemName: '',
    quantity: '',
    origin: '',
    destination: '',
    status: 'pending',
    expectedDelivery: ''
  });

  useEffect(() => {
    // Mock data - in real app, this would be an API call
    setShipments([
      {
        id: 1,
        shipmentId: 'SH-2024-001',
        itemName: 'Laptop Dell XPS 13',
        quantity: 25,
        origin: 'Dell Warehouse, Austin',
        destination: 'Tech Store, New York',
        status: 'in-transit',
        expectedDelivery: '2024-01-20',
        createdAt: '2024-01-15'
      },
      {
        id: 2,
        shipmentId: 'SH-2024-002',
        itemName: 'Office Chairs',
        quantity: 15,
        origin: 'Furniture Co, Chicago',
        destination: 'Office Supply, Los Angeles',
        status: 'delivered',
        expectedDelivery: '2024-01-18',
        createdAt: '2024-01-12'
      },
      {
        id: 3,
        shipmentId: 'SH-2024-003',
        itemName: 'Wireless Mice',
        quantity: 50,
        origin: 'Logitech Warehouse, California',
        destination: 'Electronics Store, Miami',
        status: 'pending',
        expectedDelivery: '2024-01-25',
        createdAt: '2024-01-16'
      },
      {
        id: 4,
        shipmentId: 'SH-2024-004',
        itemName: 'Desk Lamps',
        quantity: 30,
        origin: 'Lighting Co, Seattle',
        destination: 'Home Goods, Boston',
        status: 'in-transit',
        expectedDelivery: '2024-01-22',
        createdAt: '2024-01-14'
      },
      {
        id: 5,
        shipmentId: 'SH-2024-005',
        itemName: 'USB Cables',
        quantity: 100,
        origin: 'Cable Factory, China',
        destination: 'Tech Warehouse, Dallas',
        status: 'pending',
        expectedDelivery: '2024-01-30',
        createdAt: '2024-01-17'
      }
    ]);
  }, []);

  const handleAddShipment = (e) => {
    e.preventDefault();
    const newShipment = {
      id: shipments.length + 1,
      ...formData,
      quantity: parseInt(formData.quantity),
      createdAt: new Date().toISOString().split('T')[0]
    };
    setShipments([...shipments, newShipment]);
    setFormData({
      shipmentId: '',
      itemName: '',
      quantity: '',
      origin: '',
      destination: '',
      status: 'pending',
      expectedDelivery: ''
    });
    setShowAddForm(false);
  };

  const handleEditShipment = (shipment) => {
    setEditingShipment(shipment);
    setFormData({
      shipmentId: shipment.shipmentId,
      itemName: shipment.itemName,
      quantity: shipment.quantity.toString(),
      origin: shipment.origin,
      destination: shipment.destination,
      status: shipment.status,
      expectedDelivery: shipment.expectedDelivery
    });
    setShowAddForm(true);
  };

  const handleUpdateShipment = (e) => {
    e.preventDefault();
    const updatedShipments = shipments.map(shipment =>
      shipment.id === editingShipment.id
        ? { ...shipment, ...formData, quantity: parseInt(formData.quantity) }
        : shipment
    );
    setShipments(updatedShipments);
    setFormData({
      shipmentId: '',
      itemName: '',
      quantity: '',
      origin: '',
      destination: '',
      status: 'pending',
      expectedDelivery: ''
    });
    setEditingShipment(null);
    setShowAddForm(false);
  };

  const handleDeleteShipment = (id) => {
    if (window.confirm('Are you sure you want to delete this shipment?')) {
      setShipments(shipments.filter(shipment => shipment.id !== id));
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'pending': { class: 'pending', label: 'Pending' },
      'in-transit': { class: 'in-transit', label: 'In Transit' },
      'delivered': { class: 'delivered', label: 'Delivered' },
      'cancelled': { class: 'cancelled', label: 'Cancelled' }
    };
    
    const config = statusConfig[status] || statusConfig['pending'];
    return <span className={`status-badge ${config.class}`}>{config.label}</span>;
  };

  const pendingShipments = shipments.filter(s => s.status === 'pending').length;
  const inTransitShipments = shipments.filter(s => s.status === 'in-transit').length;
  const deliveredShipments = shipments.filter(s => s.status === 'delivered').length;

  return (
    <div className="shipment">
      <Sidebar />
      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">Shipment Management</h1>
          <p className="page-subtitle">Track and manage warehouse shipments</p>
        </div>

        <div className="shipment-stats">
          <div className="stat-card">
            <div className="stat-icon pending">
              <Truck size={24} />
            </div>
            <div className="stat-number">{pendingShipments}</div>
            <div className="stat-label">Pending</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon in-transit">
              <Truck size={24} />
            </div>
            <div className="stat-number">{inTransitShipments}</div>
            <div className="stat-label">In Transit</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon delivered">
              <Truck size={24} />
            </div>
            <div className="stat-number">{deliveredShipments}</div>
            <div className="stat-label">Delivered</div>
          </div>
        </div>

        <div className="shipment-controls">
          <button
            className="btn btn-primary"
            onClick={() => {
              setShowAddForm(true);
              setEditingShipment(null);
              setFormData({
                shipmentId: '',
                itemName: '',
                quantity: '',
                origin: '',
                destination: '',
                status: 'pending',
                expectedDelivery: ''
              });
            }}
          >
            <Plus size={20} />
            New Shipment
          </button>
        </div>

        {showAddForm && (
          <div className="form-container">
            <div className="card">
              <h3>{editingShipment ? 'Edit Shipment' : 'Create New Shipment'}</h3>
              <form onSubmit={editingShipment ? handleUpdateShipment : handleAddShipment}>
                <div className="form-row">
                  <div className="form-group">
                    <label>Shipment ID</label>
                    <input
                      type="text"
                      value={formData.shipmentId}
                      onChange={(e) => setFormData({ ...formData, shipmentId: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Status</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                      required
                    >
                      <option value="pending">Pending</option>
                      <option value="in-transit">In Transit</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label>Item Name</label>
                  <input
                    type="text"
                    value={formData.itemName}
                    onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                    required
                  />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Quantity</label>
                    <input
                      type="number"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                      min="1"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Expected Delivery</label>
                    <input
                      type="date"
                      value={formData.expectedDelivery}
                      onChange={(e) => setFormData({ ...formData, expectedDelivery: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>Origin</label>
                  <input
                    type="text"
                    value={formData.origin}
                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Destination</label>
                  <input
                    type="text"
                    value={formData.destination}
                    onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                    required
                  />
                </div>
                <div className="action-buttons">
                  <button type="submit" className="btn btn-success">
                    {editingShipment ? 'Update Shipment' : 'Create Shipment'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingShipment(null);
                      setFormData({
                        shipmentId: '',
                        itemName: '',
                        quantity: '',
                        origin: '',
                        destination: '',
                        status: 'pending',
                        expectedDelivery: ''
                      });
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="shipment-table">
          <div className="card">
            <table className="table">
              <thead>
                <tr>
                  <th>Shipment ID</th>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Origin</th>
                  <th>Destination</th>
                  <th>Status</th>
                  <th>Expected Delivery</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {shipments.map((shipment) => (
                  <tr key={shipment.id}>
                    <td>
                      <div className="shipment-id">
                        <Package size={16} />
                        <span>{shipment.shipmentId}</span>
                      </div>
                    </td>
                    <td>{shipment.itemName}</td>
                    <td>{shipment.quantity}</td>
                    <td>
                      <div className="location-info">
                        <MapPin size={14} />
                        <span>{shipment.origin}</span>
                      </div>
                    </td>
                    <td>
                      <div className="location-info">
                        <MapPin size={14} />
                        <span>{shipment.destination}</span>
                      </div>
                    </td>
                    <td>{getStatusBadge(shipment.status)}</td>
                    <td>
                      <div className="date-info">
                        <Calendar size={14} />
                        <span>{shipment.expectedDelivery}</span>
                      </div>
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button
                          className="btn-icon"
                          onClick={() => handleEditShipment(shipment)}
                          title="Edit"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          className="btn-icon danger"
                          onClick={() => handleDeleteShipment(shipment.id)}
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Shipment;
