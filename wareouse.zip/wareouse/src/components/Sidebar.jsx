import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Home, 
  Package, 
  MapPin, 
  Truck, 
  Wrench, 
  BarChart3, 
  LogOut,
  User
} from 'lucide-react';
import './Sidebar.css';

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const menuItems = [
    { path: '/dashboard', icon: Home, label: 'Dashboard' },
    { path: '/inventory', icon: Package, label: 'Inventory' },
    { path: '/space', icon: MapPin, label: 'Space Management' },
    { path: '/shipment', icon: Truck, label: 'Shipments' },
    { path: '/maintenance', icon: Wrench, label: 'Maintenance' },
    { path: '/reports', icon: BarChart3, label: 'Reports' },
  ];

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>LWMS</h2>
        <p>Warehouse Management</p>
      </div>
      
      <nav className="sidebar-nav">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="user-info">
          <User size={20} />
          <span>Admin User</span>
        </div>
        <button onClick={handleLogout} className="logout-btn">
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
