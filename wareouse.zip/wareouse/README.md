# Logistics Warehouse Management System (LWMS)

A comprehensive warehouse management system built with React frontend and Spring MVC backend, designed to streamline warehouse operations including inventory management, space optimization, shipment handling, maintenance scheduling, and performance reporting.

## 🏗️ Architecture

- **Frontend**: React 18 with modern UI components
- **Backend**: Spring Boot 3.2.0 with RESTful APIs
- **Database**: MySQL 8.0
- **Authentication**: JWT-based authentication
- **Security**: Spring Security with role-based access control

## 📁 Project Structure

```
warehouse-management-system/
├── frontend/                 # React frontend application
│   ├── public/
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── README.md
├── backend/                  # Spring Boot backend application
│   ├── src/
│   │   ├── main/java/com/warehouse/
│   │   │   ├── config/      # Configuration classes
│   │   │   ├── controller/  # REST controllers
│   │   │   ├── model/       # Entity models
│   │   │   ├── repository/  # Data access layer
│   │   │   ├── service/     # Business logic layer
│   │   │   └── WarehouseManagementApplication.java
│   │   └── resources/
│   │       └── application.properties
│   ├── pom.xml
│   └── README.md
└── README.md
```

## 🚀 Features

### Core Modules

1. **📦 Inventory Management**
   - Real-time stock tracking
   - SKU-based item management
   - Low stock alerts
   - Supplier management
   - Category-based organization

2. **🏢 Space Optimization**
   - Zone management (Storage, Picking, Cold Storage)
   - Capacity utilization monitoring
   - Temperature and humidity tracking
   - Space allocation optimization

3. **📮 Shipment Handling**
   - Order processing and tracking
   - Multiple shipping methods
   - Carrier management
   - Delivery status updates
   - Customer information management

4. **🔧 Maintenance Scheduling**
   - Equipment maintenance tracking
   - Priority-based task management
   - Scheduled maintenance alerts
   - Cost tracking and reporting

5. **📊 Performance Reporting**
   - Real-time dashboard analytics
   - Performance metrics
   - Custom report generation
   - Data visualization

6. **👥 User Management**
   - Role-based access control
   - User authentication and authorization
   - Profile management
   - Activity logging

## 🛠️ Technology Stack

### Frontend
- **React 18.2.0** - UI framework
- **React Router DOM 6.8.0** - Navigation
- **Lucide React** - Icons
- **CSS3** - Styling
- **Create React App** - Build tool

### Backend
- **Java 17** - Programming language
- **Spring Boot 3.2.0** - Application framework
- **Spring Data JPA** - Data persistence
- **Spring Security** - Security framework
- **MySQL 8.0** - Database
- **Maven** - Build tool

## 📋 Prerequisites

- **Node.js 16+** and **npm**
- **Java 17+**
- **Maven 3.6+**
- **MySQL 8.0+**

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone <repository-url>
cd warehouse-management-system
```

### 2. Backend Setup

```bash
cd backend

# Configure database in application.properties
# Update MySQL credentials as needed

# Build and run
mvn clean install
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm start
```

The frontend will start on `http://localhost:3000`

### 4. Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8080/api

## 👤 Demo Credentials

### Backend Users
- **Admin**: admin@warehouse.com / admin123
- **Manager**: manager@warehouse.com / manager123
- **Operator**: operator@warehouse.com / operator123

### Frontend Demo
- **Email**: admin@warehouse.com
- **Password**: admin123

## 📚 API Documentation

### Base URL: `http://localhost:8080/api`

#### Key Endpoints

**Users**
- `GET /users` - Get all users
- `POST /users` - Create user
- `PUT /users/{id}` - Update user

**Inventory**
- `GET /inventory` - Get all inventory
- `POST /inventory` - Create inventory item
- `GET /inventory/low-stock` - Get low stock items

**Spaces**
- `GET /spaces` - Get all spaces
- `POST /spaces` - Create space
- `GET /spaces/nearly-full` - Get nearly full zones

**Shipments**
- `GET /shipments` - Get all shipments
- `POST /shipments` - Create shipment
- `GET /shipments/tracking/{trackingNumber}` - Track shipment

**Maintenance**
- `GET /maintenance` - Get all maintenance tasks
- `POST /maintenance` - Create maintenance task
- `GET /maintenance/overdue` - Get overdue tasks

**Dashboard**
- `GET /dashboard/stats` - Get dashboard statistics
- `GET /dashboard/alerts` - Get system alerts

## 🔧 Configuration

### Database Configuration
Update `backend/src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/warehouse_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_password
```

### Frontend Configuration
Update API base URL in frontend components if needed.

## 🧪 Testing

### Backend Testing
```bash
cd backend
mvn test
```

### Frontend Testing
```bash
cd frontend
npm test
```

## 📦 Deployment

### Backend Deployment
```bash
cd backend
mvn clean package -DskipTests
java -jar target/warehouse-management-system-1.0.0.jar
```

### Frontend Deployment
```bash
cd frontend
npm run build
# Deploy the build folder to your web server
```

## 🔒 Security Features

- **JWT Authentication** - Secure token-based authentication
- **Role-based Access Control** - Different permissions for different user roles
- **Password Encryption** - BCrypt password hashing
- **CORS Configuration** - Secure cross-origin requests
- **Input Validation** - Server-side validation for all inputs

## 📊 Sample Data

The application comes with pre-loaded sample data:
- Demo users with different roles
- Sample inventory items (electronics, clothing, food)
- Warehouse zones (storage, picking, cold storage)
- Sample shipments with different statuses
- Maintenance tasks with various priorities

## 🎨 UI Features

- **Responsive Design** - Works on desktop, tablet, and mobile
- **Modern Interface** - Clean and intuitive user experience
- **Real-time Updates** - Live data updates and notifications
- **Interactive Components** - Dynamic forms and data tables
- **Status Indicators** - Visual status badges and progress indicators

## 🔄 Development Workflow

1. **Feature Development**
   - Create entity models in backend
   - Implement service layer business logic
   - Create REST controllers
   - Build React components for frontend
   - Test integration

2. **Testing**
   - Unit tests for backend services
   - Integration tests for APIs
   - Component tests for React
   - End-to-end testing

3. **Deployment**
   - Build backend JAR file
   - Build frontend production bundle
   - Deploy to production environment

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation in the respective frontend/backend README files

## 🔮 Future Enhancements

- **Mobile App** - Native mobile application
- **Advanced Analytics** - Machine learning insights
- **IoT Integration** - Real-time sensor data
- **Barcode Scanning** - Mobile barcode scanning
- **Advanced Reporting** - Custom report builder
- **Multi-warehouse Support** - Multiple warehouse management
- **API Rate Limiting** - Enhanced API security
- **WebSocket Support** - Real-time notifications

---

**Built with ❤️ for efficient warehouse management**
