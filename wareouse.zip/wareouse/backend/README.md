# Warehouse Management System - Backend

This is the Spring MVC backend for the Logistics Warehouse Management System (LWMS). It provides a comprehensive REST API for managing warehouse operations including inventory, space optimization, shipments, maintenance, and user management.

## Technology Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Data JPA**
- **Spring Security**
- **MySQL Database**
- **Maven**

## Project Structure

```
backend/
├── src/
│   ├── main/
│   │   ├── java/com/warehouse/
│   │   │   ├── config/           # Configuration classes
│   │   │   ├── controller/       # REST controllers
│   │   │   ├── model/           # Entity models
│   │   │   ├── repository/      # Data access layer
│   │   │   ├── service/         # Business logic layer
│   │   │   └── WarehouseManagementApplication.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/                    # Test files
├── pom.xml                      # Maven dependencies
└── README.md
```

## Features

### Core Modules

1. **User Management**
   - User registration and authentication
   - Role-based access control (Admin, Manager, Operator, Customer)
   - User profile management

2. **Inventory Management**
   - Add, update, delete inventory items
   - Track stock levels and minimum stock alerts
   - Categorize items by type
   - Supplier management
   - SKU-based tracking

3. **Space Optimization**
   - Zone management (Storage, Picking, Cold Storage, etc.)
   - Capacity tracking and utilization monitoring
   - Temperature and humidity monitoring
   - Space allocation optimization

4. **Shipment Handling**
   - Create and track shipments
   - Multiple shipping methods support
   - Carrier management
   - Delivery status tracking
   - Customer information management

5. **Maintenance Scheduling**
   - Equipment maintenance tracking
   - Priority-based task management
   - Maintenance scheduling and notifications
   - Cost tracking
   - Equipment type categorization

6. **Dashboard & Analytics**
   - Real-time statistics
   - Recent activities tracking
   - Alert system for low stock, overdue tasks, etc.
   - Performance metrics

## API Endpoints

### Base URL: `http://localhost:8080/api`

#### User Management
- `GET /users` - Get all users
- `GET /users/{id}` - Get user by ID
- `POST /users` - Create new user
- `PUT /users/{id}` - Update user
- `DELETE /users/{id}` - Delete user
- `GET /users/email/{email}` - Get user by email
- `GET /users/role/{role}` - Get users by role

#### Inventory Management
- `GET /inventory` - Get all inventory items
- `GET /inventory/{id}` - Get inventory by ID
- `POST /inventory` - Create new inventory item
- `PUT /inventory/{id}` - Update inventory item
- `DELETE /inventory/{id}` - Delete inventory item
- `GET /inventory/low-stock` - Get low stock items
- `GET /inventory/search?searchTerm=...` - Search inventory

#### Space Management
- `GET /spaces` - Get all spaces/zones
- `GET /spaces/{id}` - Get space by ID
- `POST /spaces` - Create new space
- `PUT /spaces/{id}` - Update space
- `DELETE /spaces/{id}` - Delete space
- `GET /spaces/nearly-full` - Get nearly full zones
- `PUT /spaces/{id}/used-capacity` - Update used capacity

#### Shipment Management
- `GET /shipments` - Get all shipments
- `GET /shipments/{id}` - Get shipment by ID
- `POST /shipments` - Create new shipment
- `PUT /shipments/{id}` - Update shipment
- `DELETE /shipments/{id}` - Delete shipment
- `GET /shipments/tracking/{trackingNumber}` - Track shipment
- `PUT /shipments/{id}/delivered` - Mark as delivered

#### Maintenance Management
- `GET /maintenance` - Get all maintenance tasks
- `GET /maintenance/{id}` - Get maintenance by ID
- `POST /maintenance` - Create new maintenance task
- `PUT /maintenance/{id}` - Update maintenance task
- `DELETE /maintenance/{id}` - Delete maintenance task
- `GET /maintenance/overdue` - Get overdue tasks
- `PUT /maintenance/{id}/complete` - Mark as completed

#### Dashboard
- `GET /dashboard/stats` - Get dashboard statistics
- `GET /dashboard/recent-activities` - Get recent activities
- `GET /dashboard/alerts` - Get system alerts

## Database Configuration

The application uses MySQL database. Update the database configuration in `application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/warehouse_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=password
```

## Getting Started

### Prerequisites

1. **Java 17** or higher
2. **Maven 3.6** or higher
3. **MySQL 8.0** or higher

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd warehouse-management-system/backend
   ```

2. **Configure Database**
   - Install MySQL
   - Create database (or let the application create it)
   - Update database credentials in `application.properties`

3. **Build the project**
   ```bash
   mvn clean install
   ```

4. **Run the application**
   ```bash
   mvn spring-boot:run
   ```

   Or run the JAR file:
   ```bash
   java -jar target/warehouse-management-system-1.0.0.jar
   ```

5. **Access the API**
   - Base URL: `http://localhost:8080/api`
   - Swagger UI (if configured): `http://localhost:8080/swagger-ui.html`

### Sample Data

The application automatically initializes with sample data including:
- Demo users (admin, manager, operator)
- Sample inventory items
- Sample warehouse zones
- Sample shipments
- Sample maintenance tasks

### Demo Credentials

- **Admin**: admin@warehouse.com / admin123
- **Manager**: manager@warehouse.com / manager123
- **Operator**: operator@warehouse.com / operator123

## API Documentation

### Request/Response Format

All API endpoints return JSON responses. Example:

```json
{
  "id": 1,
  "itemName": "Laptop",
  "description": "High-performance laptop",
  "sku": "LAP001",
  "quantity": 50,
  "unitPrice": 999.99,
  "category": "ELECTRONICS",
  "status": "IN_STOCK"
}
```

### Error Handling

The API returns appropriate HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `404` - Not Found
- `500` - Internal Server Error

## Security

- CORS enabled for frontend integration
- Password encryption using BCrypt
- Role-based access control
- Input validation and sanitization

## Development

### Adding New Features

1. Create entity model in `model/` package
2. Create repository interface in `repository/` package
3. Create service class in `service/` package
4. Create controller in `controller/` package
5. Add configuration if needed in `config/` package

### Testing

Run tests using Maven:
```bash
mvn test
```

### Building for Production

```bash
mvn clean package -DskipTests
```

## Deployment

### Local Deployment
```bash
mvn spring-boot:run
```

### Production Deployment
1. Build the JAR file
2. Configure production database
3. Set environment variables
4. Run with: `java -jar warehouse-management-system-1.0.0.jar`

## Integration with Frontend

The backend is designed to work with the React frontend. CORS is configured to allow requests from `http://localhost:3000`.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please contact the development team or create an issue in the repository.
