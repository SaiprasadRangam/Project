package com.warehouse.controller;

import com.warehouse.model.Inventory;
import com.warehouse.model.ItemCategory;
import com.warehouse.model.ItemStatus;
import com.warehouse.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/inventory")
@CrossOrigin(origins = "http://localhost:3000")
public class InventoryController {
    
    @Autowired
    private InventoryService inventoryService;
    
    @GetMapping
    public ResponseEntity<List<Inventory>> getAllInventory() {
        List<Inventory> inventory = inventoryService.getAllInventory();
        return ResponseEntity.ok(inventory);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Inventory> getInventoryById(@PathVariable Long id) {
        Optional<Inventory> inventory = inventoryService.getInventoryById(id);
        return inventory.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/sku/{sku}")
    public ResponseEntity<Inventory> getInventoryBySku(@PathVariable String sku) {
        Optional<Inventory> inventory = inventoryService.getInventoryBySku(sku);
        return inventory.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Inventory> createInventory(@Valid @RequestBody Inventory inventory) {
        try {
            Inventory createdInventory = inventoryService.createInventory(inventory);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdInventory);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Inventory> updateInventory(@PathVariable Long id, @Valid @RequestBody Inventory inventoryDetails) {
        try {
            Inventory updatedInventory = inventoryService.updateInventory(id, inventoryDetails);
            return ResponseEntity.ok(updatedInventory);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
        try {
            inventoryService.deleteInventory(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/category/{category}")
    public ResponseEntity<List<Inventory>> getInventoryByCategory(@PathVariable ItemCategory category) {
        List<Inventory> inventory = inventoryService.getInventoryByCategory(category);
        return ResponseEntity.ok(inventory);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Inventory>> getInventoryByStatus(@PathVariable ItemStatus status) {
        List<Inventory> inventory = inventoryService.getInventoryByStatus(status);
        return ResponseEntity.ok(inventory);
    }
    
    @GetMapping("/low-stock")
    public ResponseEntity<List<Inventory>> getLowStockItems() {
        List<Inventory> lowStockItems = inventoryService.getLowStockItems();
        return ResponseEntity.ok(lowStockItems);
    }
    
    @GetMapping("/search")
    public ResponseEntity<List<Inventory>> searchInventory(@RequestParam String searchTerm) {
        List<Inventory> inventory = inventoryService.searchInventory(searchTerm);
        return ResponseEntity.ok(inventory);
    }
    
    @GetMapping("/supplier/{supplier}")
    public ResponseEntity<List<Inventory>> getInventoryBySupplier(@PathVariable String supplier) {
        List<Inventory> inventory = inventoryService.getInventoryBySupplier(supplier);
        return ResponseEntity.ok(inventory);
    }
    
    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getInventoryCountByStatus(@PathVariable ItemStatus status) {
        long count = inventoryService.getInventoryCountByStatus(status);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/count/category/{category}")
    public ResponseEntity<Long> getInventoryCountByCategory(@PathVariable ItemCategory category) {
        long count = inventoryService.getInventoryCountByCategory(category);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/total-value")
    public ResponseEntity<Double> getTotalInventoryValue() {
        Double totalValue = inventoryService.getTotalInventoryValue();
        return ResponseEntity.ok(totalValue);
    }
    
    @GetMapping("/exists/sku/{sku}")
    public ResponseEntity<Boolean> checkSkuExists(@PathVariable String sku) {
        boolean exists = inventoryService.existsBySku(sku);
        return ResponseEntity.ok(exists);
    }
    
    @PutMapping("/{id}/quantity")
    public ResponseEntity<Inventory> updateQuantity(@PathVariable Long id, @RequestParam Integer newQuantity) {
        try {
            Inventory updatedInventory = inventoryService.updateQuantity(id, newQuantity);
            return ResponseEntity.ok(updatedInventory);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
