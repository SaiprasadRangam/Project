package com.warehouse.model;

public enum MaintenanceStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED,
    ON_HOLD
}
