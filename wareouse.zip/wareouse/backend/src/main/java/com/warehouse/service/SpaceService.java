package com.warehouse.service;

import com.warehouse.model.Space;
import com.warehouse.model.ZoneStatus;
import com.warehouse.model.ZoneType;
import com.warehouse.repository.SpaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SpaceService {
    
    @Autowired
    private SpaceRepository spaceRepository;
    
    public List<Space> getAllSpaces() {
        return spaceRepository.findAll();
    }
    
    public Optional<Space> getSpaceById(Long id) {
        return spaceRepository.findById(id);
    }
    
    public Space createSpace(Space space) {
        // Set initial used capacity to 0 if not provided
        if (space.getUsedCapacity() == null) {
            space.setUsedCapacity(0.0);
        }
        
        // Set status based on utilization
        updateZoneStatus(space);
        
        return spaceRepository.save(space);
    }
    
    public Space updateSpace(Long id, Space spaceDetails) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with id: " + id));
        
        space.setZoneName(spaceDetails.getZoneName());
        space.setDescription(spaceDetails.getDescription());
        space.setTotalCapacity(spaceDetails.getTotalCapacity());
        space.setUsedCapacity(spaceDetails.getUsedCapacity());
        space.setZoneType(spaceDetails.getZoneType());
        space.setTemperature(spaceDetails.getTemperature());
        space.setHumidity(spaceDetails.getHumidity());
        
        // Update status based on new utilization
        updateZoneStatus(space);
        
        return spaceRepository.save(space);
    }
    
    public void deleteSpace(Long id) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with id: " + id));
        spaceRepository.delete(space);
    }
    
    public List<Space> getSpacesByType(ZoneType zoneType) {
        return spaceRepository.findByZoneType(zoneType);
    }
    
    public List<Space> getSpacesByStatus(ZoneStatus status) {
        return spaceRepository.findByStatus(status);
    }
    
    public List<Space> getNearlyFullZones() {
        return spaceRepository.findNearlyFullZones();
    }
    
    public List<Space> searchSpaces(String searchTerm) {
        return spaceRepository.findByZoneNameContaining(searchTerm);
    }
    
    public long getSpacesCountByStatus(ZoneStatus status) {
        return spaceRepository.countByStatus(status);
    }
    
    public long getSpacesCountByType(ZoneType zoneType) {
        return spaceRepository.countByZoneType(zoneType);
    }
    
    public Double getTotalCapacity() {
        return spaceRepository.getTotalCapacity();
    }
    
    public Double getTotalUsedCapacity() {
        return spaceRepository.getTotalUsedCapacity();
    }
    
    public Double getAverageUtilization() {
        return spaceRepository.getAverageUtilization();
    }
    
    public Space updateUsedCapacity(Long id, Double newUsedCapacity) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with id: " + id));
        
        if (newUsedCapacity > space.getTotalCapacity()) {
            throw new RuntimeException("Used capacity cannot exceed total capacity");
        }
        
        space.setUsedCapacity(newUsedCapacity);
        updateZoneStatus(space);
        
        return spaceRepository.save(space);
    }
    
    public Space addToUsedCapacity(Long id, Double additionalCapacity) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with id: " + id));
        
        Double newUsedCapacity = space.getUsedCapacity() + additionalCapacity;
        if (newUsedCapacity > space.getTotalCapacity()) {
            throw new RuntimeException("Total used capacity would exceed total capacity");
        }
        
        space.setUsedCapacity(newUsedCapacity);
        updateZoneStatus(space);
        
        return spaceRepository.save(space);
    }
    
    public Space removeFromUsedCapacity(Long id, Double capacityToRemove) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with id: " + id));
        
        Double newUsedCapacity = space.getUsedCapacity() - capacityToRemove;
        if (newUsedCapacity < 0) {
            throw new RuntimeException("Used capacity cannot be negative");
        }
        
        space.setUsedCapacity(newUsedCapacity);
        updateZoneStatus(space);
        
        return spaceRepository.save(space);
    }
    
    private void updateZoneStatus(Space space) {
        if (space.getTotalCapacity() == null || space.getUsedCapacity() == null) {
            return;
        }
        
        double utilizationPercentage = (space.getUsedCapacity() / space.getTotalCapacity()) * 100;
        
        if (utilizationPercentage >= 100) {
            space.setStatus(ZoneStatus.FULL);
        } else if (utilizationPercentage >= 90) {
            space.setStatus(ZoneStatus.ACTIVE);
        } else if (utilizationPercentage >= 70) {
            space.setStatus(ZoneStatus.ACTIVE);
        } else {
            space.setStatus(ZoneStatus.ACTIVE);
        }
    }
}
