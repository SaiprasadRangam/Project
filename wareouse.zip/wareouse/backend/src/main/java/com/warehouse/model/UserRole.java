package com.warehouse.model;

public enum UserRole {
    ADMIN,
    MANAGER,
    OPERATOR,
    CUSTOMER
}
