package com.warehouse.model;

public enum ZoneType {
    STORAGE,
    PICKING,
    PACKING,
    SHIPPING,
    RECEIVING,
    COLD_STORAGE,
    HAZARDOUS,
    BULK_STORAGE,
    MEZZANINE,
    OFFICE
}
