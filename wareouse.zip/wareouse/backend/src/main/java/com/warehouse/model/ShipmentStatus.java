package com.warehouse.model;

public enum ShipmentStatus {
    PENDING,
    PROCESSING,
    IN_TRANSIT,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED,
    RETURNED,
    LOST
}
