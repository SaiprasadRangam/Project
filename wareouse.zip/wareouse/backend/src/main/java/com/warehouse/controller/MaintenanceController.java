package com.warehouse.controller;

import com.warehouse.model.Maintenance;
import com.warehouse.model.MaintenancePriority;
import com.warehouse.model.MaintenanceStatus;
import com.warehouse.service.MaintenanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/maintenance")
@CrossOrigin(origins = "http://localhost:3000")
public class MaintenanceController {
    
    @Autowired
    private MaintenanceService maintenanceService;
    
    @GetMapping
    public ResponseEntity<List<Maintenance>> getAllMaintenance() {
        List<Maintenance> maintenance = maintenanceService.getAllMaintenance();
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Maintenance> getMaintenanceById(@PathVariable Long id) {
        Optional<Maintenance> maintenance = maintenanceService.getMaintenanceById(id);
        return maintenance.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Maintenance> createMaintenance(@Valid @RequestBody Maintenance maintenance) {
        try {
            Maintenance createdMaintenance = maintenanceService.createMaintenance(maintenance);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Maintenance> updateMaintenance(@PathVariable Long id, @Valid @RequestBody Maintenance maintenanceDetails) {
        try {
            Maintenance updatedMaintenance = maintenanceService.updateMaintenance(id, maintenanceDetails);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMaintenance(@PathVariable Long id) {
        try {
            maintenanceService.deleteMaintenance(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Maintenance>> getMaintenanceByStatus(@PathVariable MaintenanceStatus status) {
        List<Maintenance> maintenance = maintenanceService.getMaintenanceByStatus(status);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/priority/{priority}")
    public ResponseEntity<List<Maintenance>> getMaintenanceByPriority(@PathVariable MaintenancePriority priority) {
        List<Maintenance> maintenance = maintenanceService.getMaintenanceByPriority(priority);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/assigned/{assignedTo}")
    public ResponseEntity<List<Maintenance>> getMaintenanceByAssignedTo(@PathVariable String assignedTo) {
        List<Maintenance> maintenance = maintenanceService.getMaintenanceByAssignedTo(assignedTo);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/equipment/{equipmentType}")
    public ResponseEntity<List<Maintenance>> getMaintenanceByEquipmentType(@PathVariable String equipmentType) {
        List<Maintenance> maintenance = maintenanceService.getMaintenanceByEquipmentType(equipmentType);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/scheduled-range")
    public ResponseEntity<List<Maintenance>> getMaintenanceByScheduledDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        List<Maintenance> maintenance = maintenanceService.getMaintenanceByScheduledDateRange(startDate, endDate);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/search")
    public ResponseEntity<List<Maintenance>> searchMaintenance(@RequestParam String searchTerm) {
        List<Maintenance> maintenance = maintenanceService.searchMaintenance(searchTerm);
        return ResponseEntity.ok(maintenance);
    }
    
    @GetMapping("/overdue")
    public ResponseEntity<List<Maintenance>> getOverdueTasks() {
        List<Maintenance> overdueTasks = maintenanceService.getOverdueTasks();
        return ResponseEntity.ok(overdueTasks);
    }
    
    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getMaintenanceCountByStatus(@PathVariable MaintenanceStatus status) {
        long count = maintenanceService.getMaintenanceCountByStatus(status);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/count/priority/{priority}")
    public ResponseEntity<Long> getMaintenanceCountByPriority(@PathVariable MaintenancePriority priority) {
        long count = maintenanceService.getMaintenanceCountByPriority(priority);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/total-cost")
    public ResponseEntity<Double> getTotalMaintenanceCost() {
        Double totalCost = maintenanceService.getTotalMaintenanceCost();
        return ResponseEntity.ok(totalCost);
    }
    
    @GetMapping("/average-duration")
    public ResponseEntity<Double> getAverageMaintenanceDuration() {
        Double averageDuration = maintenanceService.getAverageMaintenanceDuration();
        return ResponseEntity.ok(averageDuration);
    }
    
    @PutMapping("/{id}/status")
    public ResponseEntity<Maintenance> updateMaintenanceStatus(@PathVariable Long id, @RequestParam MaintenanceStatus newStatus) {
        try {
            Maintenance updatedMaintenance = maintenanceService.updateMaintenanceStatus(id, newStatus);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/start")
    public ResponseEntity<Maintenance> startMaintenance(@PathVariable Long id) {
        try {
            Maintenance updatedMaintenance = maintenanceService.startMaintenance(id);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/complete")
    public ResponseEntity<Maintenance> completeMaintenance(@PathVariable Long id) {
        try {
            Maintenance updatedMaintenance = maintenanceService.completeMaintenance(id);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/cancel")
    public ResponseEntity<Maintenance> cancelMaintenance(@PathVariable Long id) {
        try {
            Maintenance updatedMaintenance = maintenanceService.cancelMaintenance(id);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/hold")
    public ResponseEntity<Maintenance> putOnHold(@PathVariable Long id) {
        try {
            Maintenance updatedMaintenance = maintenanceService.putOnHold(id);
            return ResponseEntity.ok(updatedMaintenance);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
