package com.warehouse.repository;

import com.warehouse.model.Maintenance;
import com.warehouse.model.MaintenancePriority;
import com.warehouse.model.MaintenanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MaintenanceRepository extends JpaRepository<Maintenance, Long> {
    
    List<Maintenance> findByStatus(MaintenanceStatus status);
    
    List<Maintenance> findByPriority(MaintenancePriority priority);
    
    List<Maintenance> findByAssignedTo(String assignedTo);
    
    List<Maintenance> findByEquipmentType(String equipmentType);
    
    @Query("SELECT m FROM Maintenance m WHERE m.scheduledDate BETWEEN :startDate AND :endDate")
    List<Maintenance> findByScheduledDateBetween(@Param("startDate") LocalDateTime startDate, 
                                                @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT m FROM Maintenance m WHERE m.taskTitle LIKE %:title%")
    List<Maintenance> findByTaskTitleContaining(@Param("title") String title);
    
    @Query("SELECT m FROM Maintenance m WHERE m.status = 'PENDING' AND m.scheduledDate <= :date")
    List<Maintenance> findOverdueTasks(@Param("date") LocalDateTime date);
    
    @Query("SELECT COUNT(m) FROM Maintenance m WHERE m.status = :status")
    long countByStatus(@Param("status") MaintenanceStatus status);
    
    @Query("SELECT COUNT(m) FROM Maintenance m WHERE m.priority = :priority")
    long countByPriority(@Param("priority") MaintenancePriority priority);
    
    @Query("SELECT SUM(m.cost) FROM Maintenance m WHERE m.cost IS NOT NULL")
    Double getTotalMaintenanceCost();
    
    @Query("SELECT AVG(m.actualDuration) FROM Maintenance m WHERE m.actualDuration IS NOT NULL")
    Double getAverageMaintenanceDuration();
}
