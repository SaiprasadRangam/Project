package com.warehouse.service;

import com.warehouse.model.Inventory;
import com.warehouse.model.ItemCategory;
import com.warehouse.model.ItemStatus;
import com.warehouse.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventoryService {
    
    @Autowired
    private InventoryRepository inventoryRepository;
    
    public List<Inventory> getAllInventory() {
        return inventoryRepository.findAll();
    }
    
    public Optional<Inventory> getInventoryById(Long id) {
        return inventoryRepository.findById(id);
    }
    
    public Optional<Inventory> getInventoryBySku(String sku) {
        return inventoryRepository.findBySku(sku);
    }
    
    public Inventory createInventory(Inventory inventory) {
        if (inventoryRepository.existsBySku(inventory.getSku())) {
            throw new RuntimeException("Inventory with SKU " + inventory.getSku() + " already exists");
        }
        
        // Set status based on quantity
        updateItemStatus(inventory);
        
        return inventoryRepository.save(inventory);
    }
    
    public Inventory updateInventory(Long id, Inventory inventoryDetails) {
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found with id: " + id));
        
        inventory.setItemName(inventoryDetails.getItemName());
        inventory.setDescription(inventoryDetails.getDescription());
        inventory.setSku(inventoryDetails.getSku());
        inventory.setQuantity(inventoryDetails.getQuantity());
        inventory.setMinStockLevel(inventoryDetails.getMinStockLevel());
        inventory.setUnitPrice(inventoryDetails.getUnitPrice());
        inventory.setCategory(inventoryDetails.getCategory());
        inventory.setLocation(inventoryDetails.getLocation());
        inventory.setSupplier(inventoryDetails.getSupplier());
        
        // Update status based on new quantity
        updateItemStatus(inventory);
        
        return inventoryRepository.save(inventory);
    }
    
    public void deleteInventory(Long id) {
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found with id: " + id));
        inventoryRepository.delete(inventory);
    }
    
    public List<Inventory> getInventoryByCategory(ItemCategory category) {
        return inventoryRepository.findByCategory(category);
    }
    
    public List<Inventory> getInventoryByStatus(ItemStatus status) {
        return inventoryRepository.findByStatus(status);
    }
    
    public List<Inventory> getLowStockItems() {
        return inventoryRepository.findLowStockItems();
    }
    
    public List<Inventory> searchInventory(String searchTerm) {
        return inventoryRepository.findByItemNameContainingOrSkuContaining(searchTerm, searchTerm);
    }
    
    public List<Inventory> getInventoryBySupplier(String supplier) {
        return inventoryRepository.findBySupplier(supplier);
    }
    
    public long getInventoryCountByStatus(ItemStatus status) {
        return inventoryRepository.countByStatus(status);
    }
    
    public long getInventoryCountByCategory(ItemCategory category) {
        return inventoryRepository.countByCategory(category);
    }
    
    public Double getTotalInventoryValue() {
        return inventoryRepository.getTotalInventoryValue();
    }
    
    public boolean existsBySku(String sku) {
        return inventoryRepository.existsBySku(sku);
    }
    
    private void updateItemStatus(Inventory inventory) {
        if (inventory.getQuantity() == null || inventory.getMinStockLevel() == null) {
            return;
        }
        
        if (inventory.getQuantity() == 0) {
            inventory.setStatus(ItemStatus.OUT_OF_STOCK);
        } else if (inventory.getQuantity() <= inventory.getMinStockLevel()) {
            inventory.setStatus(ItemStatus.LOW_STOCK);
        } else {
            inventory.setStatus(ItemStatus.IN_STOCK);
        }
    }
    
    public Inventory updateQuantity(Long id, Integer newQuantity) {
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found with id: " + id));
        
        inventory.setQuantity(newQuantity);
        updateItemStatus(inventory);
        
        return inventoryRepository.save(inventory);
    }
}
