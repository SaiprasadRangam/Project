package com.warehouse.service;

import com.warehouse.model.Shipment;
import com.warehouse.model.ShipmentStatus;
import com.warehouse.model.ShippingMethod;
import com.warehouse.repository.ShipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ShipmentService {
    
    @Autowired
    private ShipmentRepository shipmentRepository;
    
    public List<Shipment> getAllShipments() {
        return shipmentRepository.findAll();
    }
    
    public Optional<Shipment> getShipmentById(Long id) {
        return shipmentRepository.findById(id);
    }
    
    public Optional<Shipment> getShipmentByTrackingNumber(String trackingNumber) {
        return shipmentRepository.findByTrackingNumber(trackingNumber);
    }
    
    public Shipment createShipment(Shipment shipment) {
        if (shipmentRepository.existsByTrackingNumber(shipment.getTrackingNumber())) {
            throw new RuntimeException("Shipment with tracking number " + shipment.getTrackingNumber() + " already exists");
        }
        
        return shipmentRepository.save(shipment);
    }
    
    public Shipment updateShipment(Long id, Shipment shipmentDetails) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found with id: " + id));
        
        shipment.setTrackingNumber(shipmentDetails.getTrackingNumber());
        shipment.setCustomerName(shipmentDetails.getCustomerName());
        shipment.setCustomerEmail(shipmentDetails.getCustomerEmail());
        shipment.setCustomerPhone(shipmentDetails.getCustomerPhone());
        shipment.setShippingAddress(shipmentDetails.getShippingAddress());
        shipment.setBillingAddress(shipmentDetails.getBillingAddress());
        shipment.setWeight(shipmentDetails.getWeight());
        shipment.setDimensions(shipmentDetails.getDimensions());
        shipment.setStatus(shipmentDetails.getStatus());
        shipment.setShippingMethod(shipmentDetails.getShippingMethod());
        shipment.setCarrier(shipmentDetails.getCarrier());
        shipment.setEstimatedDelivery(shipmentDetails.getEstimatedDelivery());
        shipment.setActualDelivery(shipmentDetails.getActualDelivery());
        shipment.setShippingCost(shipmentDetails.getShippingCost());
        shipment.setNotes(shipmentDetails.getNotes());
        
        return shipmentRepository.save(shipment);
    }
    
    public void deleteShipment(Long id) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found with id: " + id));
        shipmentRepository.delete(shipment);
    }
    
    public List<Shipment> getShipmentsByStatus(ShipmentStatus status) {
        return shipmentRepository.findByStatus(status);
    }
    
    public List<Shipment> getShipmentsByShippingMethod(ShippingMethod shippingMethod) {
        return shipmentRepository.findByShippingMethod(shippingMethod);
    }
    
    public List<Shipment> getShipmentsByCarrier(String carrier) {
        return shipmentRepository.findByCarrier(carrier);
    }
    
    public List<Shipment> getShipmentsByCustomerName(String customerName) {
        return shipmentRepository.findByCustomerNameContaining(customerName);
    }
    
    public List<Shipment> getShipmentsByCustomerEmail(String customerEmail) {
        return shipmentRepository.findByCustomerEmail(customerEmail);
    }
    
    public List<Shipment> getShipmentsByEstimatedDeliveryRange(LocalDateTime startDate, LocalDateTime endDate) {
        return shipmentRepository.findByEstimatedDeliveryBetween(startDate, endDate);
    }
    
    public List<Shipment> getShipmentsByCreatedDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return shipmentRepository.findByCreatedAtBetween(startDate, endDate);
    }
    
    public long getShipmentsCountByStatus(ShipmentStatus status) {
        return shipmentRepository.countByStatus(status);
    }
    
    public long getShipmentsCountByShippingMethod(ShippingMethod shippingMethod) {
        return shipmentRepository.countByShippingMethod(shippingMethod);
    }
    
    public Double getTotalShippingCost() {
        return shipmentRepository.getTotalShippingCost();
    }
    
    public boolean existsByTrackingNumber(String trackingNumber) {
        return shipmentRepository.existsByTrackingNumber(trackingNumber);
    }
    
    public Shipment updateShipmentStatus(Long id, ShipmentStatus newStatus) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found with id: " + id));
        
        shipment.setStatus(newStatus);
        
        // Set actual delivery date if status is DELIVERED
        if (newStatus == ShipmentStatus.DELIVERED && shipment.getActualDelivery() == null) {
            shipment.setActualDelivery(LocalDateTime.now());
        }
        
        return shipmentRepository.save(shipment);
    }
    
    public Shipment markAsDelivered(Long id) {
        return updateShipmentStatus(id, ShipmentStatus.DELIVERED);
    }
    
    public Shipment markAsInTransit(Long id) {
        return updateShipmentStatus(id, ShipmentStatus.IN_TRANSIT);
    }
    
    public Shipment cancelShipment(Long id) {
        return updateShipmentStatus(id, ShipmentStatus.CANCELLED);
    }
}
