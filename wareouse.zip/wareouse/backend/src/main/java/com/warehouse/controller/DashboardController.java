package com.warehouse.controller;

import com.warehouse.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/dashboard")
@CrossOrigin(origins = "http://localhost:3000")
public class DashboardController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private InventoryService inventoryService;
    
    @Autowired
    private SpaceService spaceService;
    
    @Autowired
    private ShipmentService shipmentService;
    
    @Autowired
    private MaintenanceService maintenanceService;
    
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // User statistics
        stats.put("totalUsers", userService.getAllUsers().size());
        stats.put("adminUsers", userService.getUsersCountByRole(com.warehouse.model.UserRole.ADMIN));
        stats.put("managerUsers", userService.getUsersCountByRole(com.warehouse.model.UserRole.MANAGER));
        stats.put("operatorUsers", userService.getUsersCountByRole(com.warehouse.model.UserRole.OPERATOR));
        
        // Inventory statistics
        stats.put("totalInventoryItems", inventoryService.getAllInventory().size());
        stats.put("lowStockItems", inventoryService.getLowStockItems().size());
        stats.put("outOfStockItems", inventoryService.getInventoryCountByStatus(com.warehouse.model.ItemStatus.OUT_OF_STOCK));
        stats.put("totalInventoryValue", inventoryService.getTotalInventoryValue());
        
        // Space statistics
        stats.put("totalSpaces", spaceService.getAllSpaces().size());
        stats.put("totalCapacity", spaceService.getTotalCapacity());
        stats.put("totalUsedCapacity", spaceService.getTotalUsedCapacity());
        stats.put("averageUtilization", spaceService.getAverageUtilization());
        stats.put("nearlyFullZones", spaceService.getNearlyFullZones().size());
        
        // Shipment statistics
        stats.put("totalShipments", shipmentService.getAllShipments().size());
        stats.put("pendingShipments", shipmentService.getShipmentsCountByStatus(com.warehouse.model.ShipmentStatus.PENDING));
        stats.put("inTransitShipments", shipmentService.getShipmentsCountByStatus(com.warehouse.model.ShipmentStatus.IN_TRANSIT));
        stats.put("deliveredShipments", shipmentService.getShipmentsCountByStatus(com.warehouse.model.ShipmentStatus.DELIVERED));
        stats.put("totalShippingCost", shipmentService.getTotalShippingCost());
        
        // Maintenance statistics
        stats.put("totalMaintenanceTasks", maintenanceService.getAllMaintenance().size());
        stats.put("pendingMaintenance", maintenanceService.getMaintenanceCountByStatus(com.warehouse.model.MaintenanceStatus.PENDING));
        stats.put("inProgressMaintenance", maintenanceService.getMaintenanceCountByStatus(com.warehouse.model.MaintenanceStatus.IN_PROGRESS));
        stats.put("completedMaintenance", maintenanceService.getMaintenanceCountByStatus(com.warehouse.model.MaintenanceStatus.COMPLETED));
        stats.put("overdueTasks", maintenanceService.getOverdueTasks().size());
        stats.put("totalMaintenanceCost", maintenanceService.getTotalMaintenanceCost());
        stats.put("averageMaintenanceDuration", maintenanceService.getAverageMaintenanceDuration());
        
        return ResponseEntity.ok(stats);
    }
    
    @GetMapping("/recent-activities")
    public ResponseEntity<Map<String, Object>> getRecentActivities() {
        Map<String, Object> activities = new HashMap<>();
        
        // Get recent inventory items (last 10)
        activities.put("recentInventory", inventoryService.getAllInventory().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .limit(10)
                .toList());
        
        // Get recent shipments (last 10)
        activities.put("recentShipments", shipmentService.getAllShipments().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .limit(10)
                .toList());
        
        // Get recent maintenance tasks (last 10)
        activities.put("recentMaintenance", maintenanceService.getAllMaintenance().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .limit(10)
                .toList());
        
        return ResponseEntity.ok(activities);
    }
    
    @GetMapping("/alerts")
    public ResponseEntity<Map<String, Object>> getAlerts() {
        Map<String, Object> alerts = new HashMap<>();
        
        // Low stock alerts
        alerts.put("lowStockItems", inventoryService.getLowStockItems());
        
        // Nearly full zones
        alerts.put("nearlyFullZones", spaceService.getNearlyFullZones());
        
        // Overdue maintenance tasks
        alerts.put("overdueMaintenance", maintenanceService.getOverdueTasks());
        
        // Pending shipments
        alerts.put("pendingShipments", shipmentService.getShipmentsByStatus(com.warehouse.model.ShipmentStatus.PENDING));
        
        return ResponseEntity.ok(alerts);
    }
}
