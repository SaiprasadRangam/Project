package com.warehouse.controller;

import com.warehouse.model.Space;
import com.warehouse.model.ZoneStatus;
import com.warehouse.model.ZoneType;
import com.warehouse.service.SpaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/spaces")
@CrossOrigin(origins = "http://localhost:3000")
public class SpaceController {
    
    @Autowired
    private SpaceService spaceService;
    
    @GetMapping
    public ResponseEntity<List<Space>> getAllSpaces() {
        List<Space> spaces = spaceService.getAllSpaces();
        return ResponseEntity.ok(spaces);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Space> getSpaceById(@PathVariable Long id) {
        Optional<Space> space = spaceService.getSpaceById(id);
        return space.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Space> createSpace(@Valid @RequestBody Space space) {
        try {
            Space createdSpace = spaceService.createSpace(space);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdSpace);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Space> updateSpace(@PathVariable Long id, @Valid @RequestBody Space spaceDetails) {
        try {
            Space updatedSpace = spaceService.updateSpace(id, spaceDetails);
            return ResponseEntity.ok(updatedSpace);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSpace(@PathVariable Long id) {
        try {
            spaceService.deleteSpace(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/type/{zoneType}")
    public ResponseEntity<List<Space>> getSpacesByType(@PathVariable ZoneType zoneType) {
        List<Space> spaces = spaceService.getSpacesByType(zoneType);
        return ResponseEntity.ok(spaces);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Space>> getSpacesByStatus(@PathVariable ZoneStatus status) {
        List<Space> spaces = spaceService.getSpacesByStatus(status);
        return ResponseEntity.ok(spaces);
    }
    
    @GetMapping("/nearly-full")
    public ResponseEntity<List<Space>> getNearlyFullZones() {
        List<Space> nearlyFullZones = spaceService.getNearlyFullZones();
        return ResponseEntity.ok(nearlyFullZones);
    }
    
    @GetMapping("/search")
    public ResponseEntity<List<Space>> searchSpaces(@RequestParam String searchTerm) {
        List<Space> spaces = spaceService.searchSpaces(searchTerm);
        return ResponseEntity.ok(spaces);
    }
    
    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getSpacesCountByStatus(@PathVariable ZoneStatus status) {
        long count = spaceService.getSpacesCountByStatus(status);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/count/type/{zoneType}")
    public ResponseEntity<Long> getSpacesCountByType(@PathVariable ZoneType zoneType) {
        long count = spaceService.getSpacesCountByType(zoneType);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/total-capacity")
    public ResponseEntity<Double> getTotalCapacity() {
        Double totalCapacity = spaceService.getTotalCapacity();
        return ResponseEntity.ok(totalCapacity);
    }
    
    @GetMapping("/total-used-capacity")
    public ResponseEntity<Double> getTotalUsedCapacity() {
        Double totalUsedCapacity = spaceService.getTotalUsedCapacity();
        return ResponseEntity.ok(totalUsedCapacity);
    }
    
    @GetMapping("/average-utilization")
    public ResponseEntity<Double> getAverageUtilization() {
        Double averageUtilization = spaceService.getAverageUtilization();
        return ResponseEntity.ok(averageUtilization);
    }
    
    @PutMapping("/{id}/used-capacity")
    public ResponseEntity<Space> updateUsedCapacity(@PathVariable Long id, @RequestParam Double newUsedCapacity) {
        try {
            Space updatedSpace = spaceService.updateUsedCapacity(id, newUsedCapacity);
            return ResponseEntity.ok(updatedSpace);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}/add-capacity")
    public ResponseEntity<Space> addToUsedCapacity(@PathVariable Long id, @RequestParam Double additionalCapacity) {
        try {
            Space updatedSpace = spaceService.addToUsedCapacity(id, additionalCapacity);
            return ResponseEntity.ok(updatedSpace);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}/remove-capacity")
    public ResponseEntity<Space> removeFromUsedCapacity(@PathVariable Long id, @RequestParam Double capacityToRemove) {
        try {
            Space updatedSpace = spaceService.removeFromUsedCapacity(id, capacityToRemove);
            return ResponseEntity.ok(updatedSpace);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
