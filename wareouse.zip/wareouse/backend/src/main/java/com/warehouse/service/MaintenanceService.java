package com.warehouse.service;

import com.warehouse.model.Maintenance;
import com.warehouse.model.MaintenancePriority;
import com.warehouse.model.MaintenanceStatus;
import com.warehouse.repository.MaintenanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MaintenanceService {
    
    @Autowired
    private MaintenanceRepository maintenanceRepository;
    
    public List<Maintenance> getAllMaintenance() {
        return maintenanceRepository.findAll();
    }
    
    public Optional<Maintenance> getMaintenanceById(Long id) {
        return maintenanceRepository.findById(id);
    }
    
    public Maintenance createMaintenance(Maintenance maintenance) {
        return maintenanceRepository.save(maintenance);
    }
    
    public Maintenance updateMaintenance(Long id, Maintenance maintenanceDetails) {
        Maintenance maintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Maintenance not found with id: " + id));
        
        maintenance.setTaskTitle(maintenanceDetails.getTaskTitle());
        maintenance.setDescription(maintenanceDetails.getDescription());
        maintenance.setEquipmentType(maintenanceDetails.getEquipmentType());
        maintenance.setEquipmentId(maintenanceDetails.getEquipmentId());
        maintenance.setPriority(maintenanceDetails.getPriority());
        maintenance.setStatus(maintenanceDetails.getStatus());
        maintenance.setAssignedTo(maintenanceDetails.getAssignedTo());
        maintenance.setScheduledDate(maintenanceDetails.getScheduledDate());
        maintenance.setStartDate(maintenanceDetails.getStartDate());
        maintenance.setCompletionDate(maintenanceDetails.getCompletionDate());
        maintenance.setEstimatedDuration(maintenanceDetails.getEstimatedDuration());
        maintenance.setActualDuration(maintenanceDetails.getActualDuration());
        maintenance.setCost(maintenanceDetails.getCost());
        maintenance.setPartsRequired(maintenanceDetails.getPartsRequired());
        maintenance.setNotes(maintenanceDetails.getNotes());
        
        return maintenanceRepository.save(maintenance);
    }
    
    public void deleteMaintenance(Long id) {
        Maintenance maintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Maintenance not found with id: " + id));
        maintenanceRepository.delete(maintenance);
    }
    
    public List<Maintenance> getMaintenanceByStatus(MaintenanceStatus status) {
        return maintenanceRepository.findByStatus(status);
    }
    
    public List<Maintenance> getMaintenanceByPriority(MaintenancePriority priority) {
        return maintenanceRepository.findByPriority(priority);
    }
    
    public List<Maintenance> getMaintenanceByAssignedTo(String assignedTo) {
        return maintenanceRepository.findByAssignedTo(assignedTo);
    }
    
    public List<Maintenance> getMaintenanceByEquipmentType(String equipmentType) {
        return maintenanceRepository.findByEquipmentType(equipmentType);
    }
    
    public List<Maintenance> getMaintenanceByScheduledDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return maintenanceRepository.findByScheduledDateBetween(startDate, endDate);
    }
    
    public List<Maintenance> searchMaintenance(String searchTerm) {
        return maintenanceRepository.findByTaskTitleContaining(searchTerm);
    }
    
    public List<Maintenance> getOverdueTasks() {
        return maintenanceRepository.findOverdueTasks(LocalDateTime.now());
    }
    
    public long getMaintenanceCountByStatus(MaintenanceStatus status) {
        return maintenanceRepository.countByStatus(status);
    }
    
    public long getMaintenanceCountByPriority(MaintenancePriority priority) {
        return maintenanceRepository.countByPriority(priority);
    }
    
    public Double getTotalMaintenanceCost() {
        return maintenanceRepository.getTotalMaintenanceCost();
    }
    
    public Double getAverageMaintenanceDuration() {
        return maintenanceRepository.getAverageMaintenanceDuration();
    }
    
    public Maintenance updateMaintenanceStatus(Long id, MaintenanceStatus newStatus) {
        Maintenance maintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Maintenance not found with id: " + id));
        
        maintenance.setStatus(newStatus);
        
        // Set start date if status is IN_PROGRESS
        if (newStatus == MaintenanceStatus.IN_PROGRESS && maintenance.getStartDate() == null) {
            maintenance.setStartDate(LocalDateTime.now());
        }
        
        // Set completion date if status is COMPLETED
        if (newStatus == MaintenanceStatus.COMPLETED && maintenance.getCompletionDate() == null) {
            maintenance.setCompletionDate(LocalDateTime.now());
        }
        
        return maintenanceRepository.save(maintenance);
    }
    
    public Maintenance startMaintenance(Long id) {
        return updateMaintenanceStatus(id, MaintenanceStatus.IN_PROGRESS);
    }
    
    public Maintenance completeMaintenance(Long id) {
        return updateMaintenanceStatus(id, MaintenanceStatus.COMPLETED);
    }
    
    public Maintenance cancelMaintenance(Long id) {
        return updateMaintenanceStatus(id, MaintenanceStatus.CANCELLED);
    }
    
    public Maintenance putOnHold(Long id) {
        return updateMaintenanceStatus(id, MaintenanceStatus.ON_HOLD);
    }
}
