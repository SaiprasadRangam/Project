package com.warehouse.repository;

import com.warehouse.model.Space;
import com.warehouse.model.ZoneStatus;
import com.warehouse.model.ZoneType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SpaceRepository extends JpaRepository<Space, Long> {
    
    List<Space> findByZoneType(ZoneType zoneType);
    
    List<Space> findByStatus(ZoneStatus status);
    
    @Query("SELECT s FROM Space s WHERE s.usedCapacity >= s.totalCapacity * 0.9")
    List<Space> findNearlyFullZones();
    
    @Query("SELECT s FROM Space s WHERE s.zoneName LIKE %:name%")
    List<Space> findByZoneNameContaining(@Param("name") String name);
    
    @Query("SELECT COUNT(s) FROM Space s WHERE s.status = :status")
    long countByStatus(@Param("status") ZoneStatus status);
    
    @Query("SELECT COUNT(s) FROM Space s WHERE s.zoneType = :zoneType")
    long countByZoneType(@Param("zoneType") ZoneType zoneType);
    
    @Query("SELECT SUM(s.totalCapacity) FROM Space s")
    Double getTotalCapacity();
    
    @Query("SELECT SUM(s.usedCapacity) FROM Space s")
    Double getTotalUsedCapacity();
    
    @Query("SELECT AVG((s.usedCapacity / s.totalCapacity) * 100) FROM Space s WHERE s.totalCapacity > 0")
    Double getAverageUtilization();
}
