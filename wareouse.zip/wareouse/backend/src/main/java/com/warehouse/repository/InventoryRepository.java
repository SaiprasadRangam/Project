package com.warehouse.repository;

import com.warehouse.model.Inventory;
import com.warehouse.model.ItemCategory;
import com.warehouse.model.ItemStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    
    Optional<Inventory> findBySku(String sku);
    
    boolean existsBySku(String sku);
    
    List<Inventory> findByCategory(ItemCategory category);
    
    List<Inventory> findByStatus(ItemStatus status);
    
    List<Inventory> findBySupplier(String supplier);
    
    @Query("SELECT i FROM Inventory i WHERE i.quantity <= i.minStockLevel")
    List<Inventory> findLowStockItems();
    
    @Query("SELECT i FROM Inventory i WHERE i.itemName LIKE %:name% OR i.sku LIKE %:sku%")
    List<Inventory> findByItemNameContainingOrSkuContaining(@Param("name") String name, @Param("sku") String sku);
    
    @Query("SELECT COUNT(i) FROM Inventory i WHERE i.status = :status")
    long countByStatus(@Param("status") ItemStatus status);
    
    @Query("SELECT COUNT(i) FROM Inventory i WHERE i.category = :category")
    long countByCategory(@Param("category") ItemCategory category);
    
    @Query("SELECT SUM(i.quantity * i.unitPrice) FROM Inventory i WHERE i.unitPrice IS NOT NULL")
    Double getTotalInventoryValue();
}
