package com.warehouse.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;

@Entity
@Table(name = "spaces")
public class Space {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Zone name is required")
    @Column(name = "zone_name", nullable = false)
    private String zoneName;
    
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    
    @NotNull(message = "Total capacity is required")
    @Positive(message = "Total capacity must be positive")
    @Column(name = "total_capacity", nullable = false)
    private Double totalCapacity;
    
    @NotNull(message = "Used capacity is required")
    @Column(name = "used_capacity", nullable = false)
    private Double usedCapacity;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "zone_type")
    private ZoneType zoneType;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ZoneStatus status;
    
    @Column(name = "temperature")
    private Double temperature;
    
    @Column(name = "humidity")
    private Double humidity;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) {
            status = ZoneStatus.ACTIVE;
        }
        if (usedCapacity == null) {
            usedCapacity = 0.0;
        }
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // Constructors
    public Space() {}
    
    public Space(String zoneName, String description, Double totalCapacity, 
                ZoneType zoneType, Double temperature, Double humidity) {
        this.zoneName = zoneName;
        this.description = description;
        this.totalCapacity = totalCapacity;
        this.zoneType = zoneType;
        this.temperature = temperature;
        this.humidity = humidity;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getZoneName() {
        return zoneName;
    }
    
    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Double getTotalCapacity() {
        return totalCapacity;
    }
    
    public void setTotalCapacity(Double totalCapacity) {
        this.totalCapacity = totalCapacity;
    }
    
    public Double getUsedCapacity() {
        return usedCapacity;
    }
    
    public void setUsedCapacity(Double usedCapacity) {
        this.usedCapacity = usedCapacity;
    }
    
    public ZoneType getZoneType() {
        return zoneType;
    }
    
    public void setZoneType(ZoneType zoneType) {
        this.zoneType = zoneType;
    }
    
    public ZoneStatus getStatus() {
        return status;
    }
    
    public void setStatus(ZoneStatus status) {
        this.status = status;
    }
    
    public Double getTemperature() {
        return temperature;
    }
    
    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }
    
    public Double getHumidity() {
        return humidity;
    }
    
    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Helper method to calculate utilization percentage
    public Double getUtilizationPercentage() {
        if (totalCapacity != null && totalCapacity > 0) {
            return (usedCapacity / totalCapacity) * 100;
        }
        return 0.0;
    }
    
    // Helper method to get available capacity
    public Double getAvailableCapacity() {
        if (totalCapacity != null && usedCapacity != null) {
            return totalCapacity - usedCapacity;
        }
        return 0.0;
    }
}
