package com.warehouse.repository;

import com.warehouse.model.Shipment;
import com.warehouse.model.ShipmentStatus;
import com.warehouse.model.ShippingMethod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
    
    Optional<Shipment> findByTrackingNumber(String trackingNumber);
    
    boolean existsByTrackingNumber(String trackingNumber);
    
    List<Shipment> findByStatus(ShipmentStatus status);
    
    List<Shipment> findByShippingMethod(ShippingMethod shippingMethod);
    
    List<Shipment> findByCarrier(String carrier);
    
    List<Shipment> findByCustomerNameContaining(String customerName);
    
    List<Shipment> findByCustomerEmail(String customerEmail);
    
    @Query("SELECT s FROM Shipment s WHERE s.estimatedDelivery BETWEEN :startDate AND :endDate")
    List<Shipment> findByEstimatedDeliveryBetween(@Param("startDate") LocalDateTime startDate, 
                                                  @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT s FROM Shipment s WHERE s.createdAt BETWEEN :startDate AND :endDate")
    List<Shipment> findByCreatedAtBetween(@Param("startDate") LocalDateTime startDate, 
                                         @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT COUNT(s) FROM Shipment s WHERE s.status = :status")
    long countByStatus(@Param("status") ShipmentStatus status);
    
    @Query("SELECT COUNT(s) FROM Shipment s WHERE s.shippingMethod = :shippingMethod")
    long countByShippingMethod(@Param("shippingMethod") ShippingMethod shippingMethod);
    
    @Query("SELECT SUM(s.shippingCost) FROM Shipment s WHERE s.shippingCost IS NOT NULL")
    Double getTotalShippingCost();
}
