package com.warehouse.model;

public enum EquipmentType {
    FORKLIFT,
    CONVEYOR,
    PALLET_JACK,
    CRANE,
    HOIST,
    COMPRESSOR,
    HVAC,
    LIGHTING,
    SECURITY_SYSTEM,
    COMPUTER,
    PRINTER,
    SCANNER,
    OTHER
}
