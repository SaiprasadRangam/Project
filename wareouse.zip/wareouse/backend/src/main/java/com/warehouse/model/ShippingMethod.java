package com.warehouse.model;

public enum ShippingMethod {
    STANDARD,
    EXPRESS,
    OVERNIGHT,
    SAME_DAY,
    ECONOMY,
    FREIGHT,
    AIR_FREIGHT,
    SEA_FREIGHT
}
