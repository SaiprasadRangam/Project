package com.warehouse.model;

public enum ItemStatus {
    IN_STOCK,
    LOW_STOCK,
    OUT_OF_STOCK,
    DISCONTINUED,
    ON_ORDER
}
