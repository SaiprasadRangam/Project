package com.warehouse.model;

public enum ZoneStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE,
    RESERVED,
    FULL
}
