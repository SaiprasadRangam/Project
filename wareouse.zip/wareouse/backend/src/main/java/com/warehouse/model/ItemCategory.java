package com.warehouse.model;

public enum ItemCategory {
    ELECTRONICS,
    CLOTHING,
    FOOD,
    FURNITURE,
    AUTOMOTIVE,
    BOOKS,
    TOYS,
    SPORTS,
    HEALTH,
    BEAUTY,
    OTHER
}
