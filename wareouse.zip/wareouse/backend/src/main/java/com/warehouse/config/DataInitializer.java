package com.warehouse.config;

import com.warehouse.model.*;
import com.warehouse.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private InventoryRepository inventoryRepository;
    
    @Autowired
    private SpaceRepository spaceRepository;
    
    @Autowired
    private ShipmentRepository shipmentRepository;
    
    @Autowired
    private MaintenanceRepository maintenanceRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) throws Exception {
        // Only initialize if no data exists
        if (userRepository.count() == 0) {
            initializeUsers();
        }
        if (inventoryRepository.count() == 0) {
            initializeInventory();
        }
        if (spaceRepository.count() == 0) {
            initializeSpaces();
        }
        if (shipmentRepository.count() == 0) {
            initializeShipments();
        }
        if (maintenanceRepository.count() == 0) {
            initializeMaintenance();
        }
    }
    
    private void initializeUsers() {
        User admin = new User();
        admin.setFullName("Admin User");
        admin.setEmail("admin@warehouse.com");
        admin.setPhone("1234567890");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRole(UserRole.ADMIN);
        userRepository.save(admin);
        
        User manager = new User();
        manager.setFullName("Manager User");
        manager.setEmail("manager@warehouse.com");
        manager.setPhone("1234567891");
        manager.setPassword(passwordEncoder.encode("manager123"));
        manager.setRole(UserRole.MANAGER);
        userRepository.save(manager);
        
        User operator = new User();
        operator.setFullName("Operator User");
        operator.setEmail("operator@warehouse.com");
        operator.setPhone("1234567892");
        operator.setPassword(passwordEncoder.encode("operator123"));
        operator.setRole(UserRole.OPERATOR);
        userRepository.save(operator);
    }
    
    private void initializeInventory() {
        // Electronics
        Inventory laptop = new Inventory();
        laptop.setItemName("Laptop");
        laptop.setDescription("High-performance laptop");
        laptop.setSku("LAP001");
        laptop.setQuantity(50);
        laptop.setMinStockLevel(10);
        laptop.setUnitPrice(999.99);
        laptop.setCategory(ItemCategory.ELECTRONICS);
        laptop.setLocation("Zone A-1");
        laptop.setSupplier("TechCorp");
        inventoryRepository.save(laptop);
        
        // Clothing
        Inventory tshirt = new Inventory();
        tshirt.setItemName("T-Shirt");
        tshirt.setDescription("Cotton t-shirt");
        tshirt.setSku("TSH001");
        tshirt.setQuantity(200);
        tshirt.setMinStockLevel(50);
        tshirt.setUnitPrice(19.99);
        tshirt.setCategory(ItemCategory.CLOTHING);
        tshirt.setLocation("Zone B-1");
        tshirt.setSupplier("FashionCo");
        inventoryRepository.save(tshirt);
        
        // Food
        Inventory coffee = new Inventory();
        coffee.setItemName("Coffee Beans");
        coffee.setDescription("Premium coffee beans");
        coffee.setSku("COF001");
        coffee.setQuantity(100);
        coffee.setMinStockLevel(20);
        coffee.setUnitPrice(15.99);
        coffee.setCategory(ItemCategory.FOOD);
        coffee.setLocation("Zone C-1");
        coffee.setSupplier("CoffeeCo");
        inventoryRepository.save(coffee);
    }
    
    private void initializeSpaces() {
        // Storage Zone
        Space storageZone = new Space();
        storageZone.setZoneName("Storage Zone A");
        storageZone.setDescription("General storage area");
        storageZone.setTotalCapacity(1000.0);
        storageZone.setUsedCapacity(750.0);
        storageZone.setZoneType(ZoneType.STORAGE);
        storageZone.setTemperature(20.0);
        storageZone.setHumidity(45.0);
        spaceRepository.save(storageZone);
        
        // Picking Zone
        Space pickingZone = new Space();
        pickingZone.setZoneName("Picking Zone B");
        pickingZone.setDescription("Order picking area");
        pickingZone.setTotalCapacity(500.0);
        pickingZone.setUsedCapacity(300.0);
        pickingZone.setZoneType(ZoneType.PICKING);
        pickingZone.setTemperature(22.0);
        pickingZone.setHumidity(50.0);
        spaceRepository.save(pickingZone);
        
        // Cold Storage
        Space coldStorage = new Space();
        coldStorage.setZoneName("Cold Storage C");
        coldStorage.setDescription("Refrigerated storage");
        coldStorage.setTotalCapacity(200.0);
        coldStorage.setUsedCapacity(150.0);
        coldStorage.setZoneType(ZoneType.COLD_STORAGE);
        coldStorage.setTemperature(4.0);
        coldStorage.setHumidity(60.0);
        spaceRepository.save(coldStorage);
    }
    
    private void initializeShipments() {
        // Pending Shipment
        Shipment pendingShipment = new Shipment();
        pendingShipment.setTrackingNumber("TRK001");
        pendingShipment.setCustomerName("John Doe");
        pendingShipment.setCustomerEmail("john@example.com");
        pendingShipment.setCustomerPhone("5551234567");
        pendingShipment.setShippingAddress("123 Main St, City, State 12345");
        pendingShipment.setWeight(5.5);
        pendingShipment.setShippingMethod(ShippingMethod.STANDARD);
        pendingShipment.setCarrier("FedEx");
        pendingShipment.setEstimatedDelivery(LocalDateTime.now().plusDays(3));
        pendingShipment.setShippingCost(25.99);
        shipmentRepository.save(pendingShipment);
        
        // In Transit Shipment
        Shipment inTransitShipment = new Shipment();
        inTransitShipment.setTrackingNumber("TRK002");
        inTransitShipment.setCustomerName("Jane Smith");
        inTransitShipment.setCustomerEmail("jane@example.com");
        inTransitShipment.setCustomerPhone("5559876543");
        inTransitShipment.setShippingAddress("456 Oak Ave, City, State 12345");
        inTransitShipment.setWeight(12.0);
        inTransitShipment.setStatus(ShipmentStatus.IN_TRANSIT);
        inTransitShipment.setShippingMethod(ShippingMethod.EXPRESS);
        inTransitShipment.setCarrier("UPS");
        inTransitShipment.setEstimatedDelivery(LocalDateTime.now().plusDays(1));
        inTransitShipment.setShippingCost(45.99);
        shipmentRepository.save(inTransitShipment);
    }
    
    private void initializeMaintenance() {
        // Pending Maintenance
        Maintenance pendingMaintenance = new Maintenance();
        pendingMaintenance.setTaskTitle("Forklift Inspection");
        pendingMaintenance.setDescription("Regular safety inspection of forklift FL001");
        pendingMaintenance.setEquipmentType(EquipmentType.FORKLIFT);
        pendingMaintenance.setEquipmentId("FL001");
        pendingMaintenance.setPriority(MaintenancePriority.MEDIUM);
        pendingMaintenance.setAssignedTo("John Technician");
        pendingMaintenance.setScheduledDate(LocalDateTime.now().plusDays(2));
        pendingMaintenance.setEstimatedDuration(4);
        maintenanceRepository.save(pendingMaintenance);
        
        // In Progress Maintenance
        Maintenance inProgressMaintenance = new Maintenance();
        inProgressMaintenance.setTaskTitle("Conveyor Belt Repair");
        inProgressMaintenance.setDescription("Repair damaged conveyor belt in Zone A");
        inProgressMaintenance.setEquipmentType(EquipmentType.CONVEYOR);
        inProgressMaintenance.setEquipmentId("CONV001");
        inProgressMaintenance.setPriority(MaintenancePriority.HIGH);
        inProgressMaintenance.setStatus(MaintenanceStatus.IN_PROGRESS);
        inProgressMaintenance.setAssignedTo("Mike Engineer");
        inProgressMaintenance.setScheduledDate(LocalDateTime.now().minusDays(1));
        inProgressMaintenance.setStartDate(LocalDateTime.now().minusHours(2));
        inProgressMaintenance.setEstimatedDuration(8);
        maintenanceRepository.save(inProgressMaintenance);
    }
}
