package com.warehouse.model;

public enum MaintenancePriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
