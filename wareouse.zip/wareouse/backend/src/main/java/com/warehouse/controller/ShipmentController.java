package com.warehouse.controller;

import com.warehouse.model.Shipment;
import com.warehouse.model.ShipmentStatus;
import com.warehouse.model.ShippingMethod;
import com.warehouse.service.ShipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/shipments")
@CrossOrigin(origins = "http://localhost:3000")
public class ShipmentController {
    
    @Autowired
    private ShipmentService shipmentService;
    
    @GetMapping
    public ResponseEntity<List<Shipment>> getAllShipments() {
        List<Shipment> shipments = shipmentService.getAllShipments();
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Shipment> getShipmentById(@PathVariable Long id) {
        Optional<Shipment> shipment = shipmentService.getShipmentById(id);
        return shipment.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/tracking/{trackingNumber}")
    public ResponseEntity<Shipment> getShipmentByTrackingNumber(@PathVariable String trackingNumber) {
        Optional<Shipment> shipment = shipmentService.getShipmentByTrackingNumber(trackingNumber);
        return shipment.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Shipment> createShipment(@Valid @RequestBody Shipment shipment) {
        try {
            Shipment createdShipment = shipmentService.createShipment(shipment);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Shipment> updateShipment(@PathVariable Long id, @Valid @RequestBody Shipment shipmentDetails) {
        try {
            Shipment updatedShipment = shipmentService.updateShipment(id, shipmentDetails);
            return ResponseEntity.ok(updatedShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteShipment(@PathVariable Long id) {
        try {
            shipmentService.deleteShipment(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Shipment>> getShipmentsByStatus(@PathVariable ShipmentStatus status) {
        List<Shipment> shipments = shipmentService.getShipmentsByStatus(status);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/method/{shippingMethod}")
    public ResponseEntity<List<Shipment>> getShipmentsByShippingMethod(@PathVariable ShippingMethod shippingMethod) {
        List<Shipment> shipments = shipmentService.getShipmentsByShippingMethod(shippingMethod);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/carrier/{carrier}")
    public ResponseEntity<List<Shipment>> getShipmentsByCarrier(@PathVariable String carrier) {
        List<Shipment> shipments = shipmentService.getShipmentsByCarrier(carrier);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/customer/name/{customerName}")
    public ResponseEntity<List<Shipment>> getShipmentsByCustomerName(@PathVariable String customerName) {
        List<Shipment> shipments = shipmentService.getShipmentsByCustomerName(customerName);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/customer/email/{customerEmail}")
    public ResponseEntity<List<Shipment>> getShipmentsByCustomerEmail(@PathVariable String customerEmail) {
        List<Shipment> shipments = shipmentService.getShipmentsByCustomerEmail(customerEmail);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/delivery-range")
    public ResponseEntity<List<Shipment>> getShipmentsByEstimatedDeliveryRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        List<Shipment> shipments = shipmentService.getShipmentsByEstimatedDeliveryRange(startDate, endDate);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/created-range")
    public ResponseEntity<List<Shipment>> getShipmentsByCreatedDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        List<Shipment> shipments = shipmentService.getShipmentsByCreatedDateRange(startDate, endDate);
        return ResponseEntity.ok(shipments);
    }
    
    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getShipmentsCountByStatus(@PathVariable ShipmentStatus status) {
        long count = shipmentService.getShipmentsCountByStatus(status);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/count/method/{shippingMethod}")
    public ResponseEntity<Long> getShipmentsCountByShippingMethod(@PathVariable ShippingMethod shippingMethod) {
        long count = shipmentService.getShipmentsCountByShippingMethod(shippingMethod);
        return ResponseEntity.ok(count);
    }
    
    @GetMapping("/total-shipping-cost")
    public ResponseEntity<Double> getTotalShippingCost() {
        Double totalCost = shipmentService.getTotalShippingCost();
        return ResponseEntity.ok(totalCost);
    }
    
    @GetMapping("/exists/tracking/{trackingNumber}")
    public ResponseEntity<Boolean> checkTrackingNumberExists(@PathVariable String trackingNumber) {
        boolean exists = shipmentService.existsByTrackingNumber(trackingNumber);
        return ResponseEntity.ok(exists);
    }
    
    @PutMapping("/{id}/status")
    public ResponseEntity<Shipment> updateShipmentStatus(@PathVariable Long id, @RequestParam ShipmentStatus newStatus) {
        try {
            Shipment updatedShipment = shipmentService.updateShipmentStatus(id, newStatus);
            return ResponseEntity.ok(updatedShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/delivered")
    public ResponseEntity<Shipment> markAsDelivered(@PathVariable Long id) {
        try {
            Shipment updatedShipment = shipmentService.markAsDelivered(id);
            return ResponseEntity.ok(updatedShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/in-transit")
    public ResponseEntity<Shipment> markAsInTransit(@PathVariable Long id) {
        try {
            Shipment updatedShipment = shipmentService.markAsInTransit(id);
            return ResponseEntity.ok(updatedShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}/cancel")
    public ResponseEntity<Shipment> cancelShipment(@PathVariable Long id) {
        try {
            Shipment updatedShipment = shipmentService.cancelShipment(id);
            return ResponseEntity.ok(updatedShipment);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
